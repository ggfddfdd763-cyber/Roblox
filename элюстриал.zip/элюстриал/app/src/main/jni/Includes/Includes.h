#include "imgui.h"
#include "imgui_internal.h"
#include <string>
#include <vector>
#include <functional>
#include "MenuFonts/icons.h"
#include "MenuFonts/monster.h"
#include "ImGui/toogle_button.h"
#include "Main/menu_style.h"
#include "Main/custom.h"
#include "Main/colorpicker.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "backends/imgui_impl_opengl3.h"
#include "../ImGui/imgui_internal.h"

bool MenuPage1 = true;
bool MenuPage2 = false;
bool MenuPage3 = false;
bool MenuPage4 = false;
bool MenuPage5 = false;
