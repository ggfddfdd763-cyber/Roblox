#ifndef UTILS
#define UTILS

#include <jni.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include "Logger.h"
typedef unsigned long DWORD;
JNIEnv *enve; 

bool isLibraryLoaded(const char *libraryName) {
    //libLoaded = true;
    char line[512] = {0};
    FILE *fp = fopen(oxorany("/proc/self/maps"), oxorany("rt"));
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            std::string a = line;
            if (strstr(line, libraryName)) {
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}
void Toast(JNIEnv *env, const char *text, int length) { 
   jstring jstr = env->NewStringUTF(text); 
   jclass toast = env->FindClass("android/widget/Toast"); 
   jmethodID methodMakeText = env->GetStaticMethodID(toast,"makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;"); 
   jclass activityThread = env->FindClass("android/app/ActivityThread"); 
   jmethodID currentActivityThread = env->GetStaticMethodID(activityThread, "currentActivityThread", "()Landroid/app/ActivityThread;"); 
   jobject at = env->CallStaticObjectMethod(activityThread, currentActivityThread); 
   jmethodID getApplication = env->GetMethodID(activityThread, "getApplication", "()Landroid/app/Application;"); 
   jobject context = env->CallObjectMethod(at, getApplication); 
   jobject toastobj = env->CallStaticObjectMethod(toast, methodMakeText,context, jstr, length); 
   jmethodID methodShow = env->GetMethodID(toast, "show", "()V"); 
 env->CallVoidMethod(toastobj, methodShow); 
}

#endif
