namespace TurboMods {
    void DrawLineGlowW(ImVec2 start, ImVec2 end, ImColor col, float size, int gsize) {
       ImGui::GetBackgroundDrawList()->AddLine(start, end, col, size);
       for (int i = 0; i < gsize; i++) {
         ImGui::GetBackgroundDrawList()->AddLine(start, end,ImColor(col.Value.x, col.Value.y, col.Value.z, col.Value.w * (1.0f / (float)gsize) * (((float) (gsize - i)) / (float) gsize)), size + i);
       }
    }

    void DrawLineGlow(ImVec2 start,ImVec2 end,ImVec4 col,float size, int gsize) {
        ImGui::GetBackgroundDrawList()->AddLine(start,end,ImGui::GetColorU32(col),size);
        for(int i = 0; i < gsize; i++) {
            ImGui::GetBackgroundDrawList()->AddLine(start,end,ImGui::GetColorU32(ImVec4(col.x,col.y,col.z,col.w * (1.0f / (float)gsize) * (((float)(gsize - i))/(float)gsize))),size + i);
        }
    }

    const std::string currentDateTime() {
        time_t now = time(0);
        struct tm tstruct;
        char buft[80];
        tstruct = *localtime(&now);
        strftime(buft, sizeof(buft), "%X", &tstruct);
        return buft;
    }

    static void HelpMarker(const char* desc) {
      ImGui::TextDisabled("(?)");
      if (ImGui::IsItemHovered()) {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
      }
    }

    float toasttimer = 0;
    float toastmaxtime = 0;
    const char* toasttext = 0;

    void Toast(const char *text, int length = 1) {
        TurboMods::toasttext = text;
        TurboMods::toasttimer = length;
        TurboMods::toastmaxtime = length;
    }
    
    void AddColorPicker(const char* name, ImVec4 &color, bool prd = false, bool* rainbow = nullptr, bool* pulse = nullptr, bool* dark = nullptr) {
        ImGuiColorEditFlags misc_flags = ImGuiColorEditFlags_AlphaPreview;
        static ImVec4 backup_color;
        bool open_popup = ImGui::ColorButton((std::string(name) + std::string(oxorany("##3b"))).c_str(), color, misc_flags);
        if (open_popup) {
            ImGui::OpenPopup(name);
            backup_color = color;
        }
        if (ImGui::BeginPopup(name)) {
            ImGui::Text(oxorany("%s"), std::string(name).c_str());
            ImGui::Separator();
            ImGui::ColorPicker4(oxorany("##picker"), (float *) &color,misc_flags | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_AlphaBar);
            ImGui::SameLine();
            ImGui::BeginGroup();
            ImGui::Text(oxorany("%s"),std::string(oxorany("Current")).c_str());
            ImGui::ColorButton(oxorany("##current"), color,ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf,ImVec2(60, 40));
            ImGui::Text(oxorany("%s"),std::string(oxorany("Previous")).c_str());
            if (ImGui::ColorButton(oxorany("##previous"), backup_color,ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf,ImVec2(60, 40)))color = backup_color;
            ImGui::EndGroup();
            if (prd) {
                if (rainbow) ImGui::Checkbox(oxorany("rainbow"), rainbow);
                if (pulse) ImGui::Checkbox(oxorany("pulse"), pulse);
                if (dark) ImGui::Checkbox(oxorany("dark"), dark);
            }
            ImGui::EndPopup();
        }
    }

    void RenderToast() {
        ImGuiIO &io = ImGui::GetIO();
        if (toasttimer <= 0) return;
        toasttimer -= io.DeltaTime;
        float alpha;
        if (toasttimer >= 0.1f && toasttimer <= toastmaxtime - 0.1f) alpha = 1;
        if (toasttimer < 0.1f) alpha = toasttimer * 10;
        if (toasttimer > toastmaxtime - 0.1f) alpha = (toastmaxtime - toasttimer) * 10;

        ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2(io.DisplaySize.x / 2 - ImGui::CalcTextSize(toasttext).x/2 - 20, io.DisplaySize.y * 0.8 - ImGui::CalcTextSize(toasttext).y/2 - 20 - alpha * 5), ImVec2(io.DisplaySize.x / 2 + ImGui::CalcTextSize(toasttext).x/2 + 20, io.DisplaySize.y * 0.8 + ImGui::CalcTextSize(toasttext).y/2 + 20 - alpha * 5), ImColor(0.1f,0.1f,0.1f,alpha), 5.0f);
        ImGui::GetForegroundDrawList()->AddText(ImVec2(io.DisplaySize.x / 2 - ImGui::CalcTextSize(toasttext).x/2, io.DisplaySize.y * 0.8 - ImGui::CalcTextSize(toasttext).y/2 - alpha * 5), ImColor(1.0f,1.0f,1.0f,alpha), toasttext);
    }

    void TextCentered(std::string text) {
        auto windowWidth = ImGui::GetWindowSize().x;
        auto textWidth = ImGui::CalcTextSize(text.c_str()).x;
        ImGui::SetCursorPosX((windowWidth - textWidth) * 0.5f);
        ImGui::Text(text.c_str());
    }

    void MultiCombo(const char* label, bool combos[], const char* items[], int items_count)
    {

        std::vector<std::string> vec;
        static std::string preview;
        for (int i = 0, j = 0; i < items_count; i++)
        {
            if (combos[i])
            {
                vec.push_back(items[i]);
                if (j > 2)
                    preview = vec.at(0) + ", " + vec.at(1) + ", " + vec.at(2) + ", ...";
                else if (j)
                    preview += ", " + (std::string)items[i];
                else
                    preview = items[i];

                j++;
            }
        }
        if (ImGui::BeginCombo(label, preview.c_str())) {
            for (int i = 0; i < items_count; i++) {
                ImGui::Selectable(items[i], &combos[i], ImGuiSelectableFlags_DontClosePopups);
            }
            ImGui::EndCombo();
        }
        preview = "None";
    }


} //namespace Alacrium (ex. MenuCustoms)
