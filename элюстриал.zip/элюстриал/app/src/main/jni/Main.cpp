#include <fstream>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <backends/imgui_impl_opengl3.h>
#include <backends/imgui_impl_android.h>
#include <ByNameModding/BNM.hpp>
#include <libraries/Json.h>
#include <libraries/Obfuscate.h>
#include <libraries/Font.h>
#include <libraries/Rainbow.h>
#include "Misc/Logger.h"
#include "Misc/Oxorany.h"
#include "Misc/Utils.h"

using namespace std;
using namespace json;
using namespace ImGui;
using namespace BNM;
using namespace MONO_STRUCTS;
using namespace UNITY_STRUCTS;

bool a = false;
bool g_initialized;
ImU32 g_rainbow;


#include <Configuration/config-main.h>
#include <Others/hooks-main.h>
#include <Main/menu-main.h>
#include <Others/esp-main.h>


EGLBoolean (*orig_eglSwapBuffers)(...);
EGLBoolean hook_eglSwapBuffers(EGLDisplay display, EGLSurface surface) {
	if (!g_initialized) {
		CreateContext();
		ImGui_ImplOpenGL3_Init("#version 100");
        GetIO().Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 24.0f, NULL, GetIO().Fonts->GetGlyphRangesCyrillic());
        
        ImGuiIO& io = ImGui::GetIO();
		monster_font = io.Fonts->AddFontFromMemoryTTF(&monster, sizeof monster, 24.0f);
		icon_font = io.Fonts->AddFontFromMemoryTTF(icons, sizeof icons, 39);
		teroryhack = io.Fonts->AddFontFromMemoryTTF(&terory, sizeof terory, 12.5f);
		defualt_font = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 24.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
		EspFont = io.Fonts->AddFontFromMemoryTTF(Tahoma, sizeof Tahoma, 20);
		InitStyle();
	}

	GetIO().DisplaySize = ImVec2(Screen$$width(), Screen$$height());
	ImGui_ImplOpenGL3_NewFrame();
	NewFrame();
	RenderToast();
	Rainbow::Update();
	MainMenu::DrawMenu();
	Esp::DrawEsp();
	EndFrame();
	Render();
	
	ImGui_ImplOpenGL3_RenderDrawData(GetDrawData());
	g_initialized = true;
	return orig_eglSwapBuffers(display, surface);
}

#define HOOK(ret, func, ...)        \
ret (*orig##func)(__VA_ARGS__); \
ret my##func(__VA_ARGS__)

HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac) {
	origInput(thiz, ex_ab, ex_ac);

	if (g_initialized) {
		ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
	}
}

bool IsShader(const char *name) {
	GLint currProgram;
	glGetIntegerv(GL_CURRENT_PROGRAM, &currProgram);
	return glGetUniformLocation(currProgram, name) != -1;
}

void(*orig_glDrawElements)(...);
void hook_glDrawElements(GLenum mode, GLsizei count, GLenum type, const void *indices) {
	if (chamsEnable) {
		if (IsShader("unity_SHC")) {
			glEnable(GL_BLEND);
			glBlendFunc(GL_ONE, GL_CONSTANT_COLOR);
			if (chamsRainbow)
				glBlendColor(Rainbow::GetColor().x, Rainbow::GetColor().y, Rainbow::GetColor().z, Rainbow::GetColor().w);
			else
				glBlendColor(chamsColor[0], chamsColor[1], chamsColor[2], chamsColor[3]);
		}
	}
	glDrawElements(mode, count, type, indices);
}

#include <thread>
[[maybe_unused]] __attribute__((constructor)) void lib_main() {
	thread(InitializeOffsets).detach();
	DobbyHook((void *)dlsym(RTLD_NEXT, "eglSwapBuffers"), (void *)hook_eglSwapBuffers, (void **)&orig_eglSwapBuffers);
	DobbyHook((void *)DobbySymbolResolver("/system/lib/libinput.so", "_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE"), (void *)myInput, (void **)&origInput);
	DobbyHook((void *)dlsym(dlopen("libGLESv2.so", RTLD_LAZY), "glDrawElements"), (void *)hook_glDrawElements, (void **)&orig_glDrawElements);
}
