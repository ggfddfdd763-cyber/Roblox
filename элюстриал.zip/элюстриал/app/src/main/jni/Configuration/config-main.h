#include "Includes/bools.h"

static const string WAY_FOR_CFG = "/storage/emulated/0/Android/data/com.skullcapstudios.bpm/";
static const string NAME_CFG = "Config";
static const string TYPE_CFG = ".json";

void LoadConfig(const int NUMBER) {
ifstream file(WAY_FOR_CFG + NAME_CFG + to_string(NUMBER) + TYPE_CFG);
if (!file.is_open()) return;
string text;
file.seekg(0, ios::end);
text.resize(file.tellg());
file.seekg(0, ios::beg);
file.read(&text[0], text.size());
JSON config = JSON::Load(text);

silentEnable=config["Aim Silent"].ToBool();
silentAim=config["Silent aim"].ToBool();
silentEnable=config["Resolver"].ToBool();
autofire=config["Auto fire"].ToBool();
silentHead=config["HitBox - Head"].ToBool();
fovEnable=config["Draw fov"].ToBool();
fovRadius=config["Radius fov"].ToFloat();

fovDefualt=config["Fov Defualt"].ToBool();
fovOutline=config["Fov Outline"].ToBool();
AntiAim=config["Anti Aim"].ToBool();
AA_Spin=config["Mode: Spin"].ToBool();
AA_Speed=config["Mode: Spin Speed"].ToFloat();
AA_SpinDefualt=config["Pitch: Spin Defualt"].ToBool();
AA_SpinUp=config["Pitch: Spin Up"].ToBool();

EspLineTop=config["ESP Line Top"].ToBool();
EspLineCenter=config["ESP Line Center"].ToBool();
EspLineBottom=config["ESP Line Bottom"].ToBool();

lineColor[0]=config["Line color"]["1"].ToFloat();
lineColor[1]=config["Line color"]["2"].ToFloat();
lineColor[2]=config["Line color"]["3"].ToFloat();
lineColor[3]=config["Line color"]["4"].ToFloat();

EspBox=config["ESP Box"].ToBool();
rectColor[0]=config["Box color"]["1"].ToFloat();
rectColor[1]=config["Box color"]["2"].ToFloat();
rectColor[2]=config["Box color"]["3"].ToFloat();
rectColor[3]=config["Box color"]["4"].ToFloat();

EspGradient=config["ESP Gradient"].ToBool();
GradientColor[0]=config["Grad color"]["1"].ToFloat();
GradientColor[1]=config["Grad color"]["2"].ToFloat();
GradientColor[2]=config["Grad color"]["3"].ToFloat();
GradientColor[3]=config["Grad color"]["4"].ToFloat();

EspHealth=config["ESP Health"].ToBool();
HealthColor[0]=config["Health color"]["1"].ToFloat();
HealthColor[1]=config["Health color"]["2"].ToFloat();
HealthColor[2]=config["Health color"]["3"].ToFloat();
HealthColor[3]=config["Health color"]["4"].ToFloat();

EspArmor=config["ESP Armor"].ToBool();
ArmorColor[0]=config["Armor color"]["1"].ToFloat();
ArmorColor[1]=config["Armor color"]["2"].ToFloat();
ArmorColor[2]=config["Armor color"]["3"].ToFloat();
ArmorColor[3]=config["Armor color"]["4"].ToFloat();

EspNickname=config["ESP Name"].ToBool();
nicknameColor[0]=config["Name color"]["1"].ToFloat();
nicknameColor[1]=config["Name color"]["2"].ToFloat();
nicknameColor[2]=config["Name color"]["3"].ToFloat();
nicknameColor[3]=config["Name color"]["4"].ToFloat();

EspMoney=config["ESP Money"].ToBool();
moneyColor[0]=config["Money color"]["1"].ToFloat();
moneyColor[1]=config["Money color"]["2"].ToFloat();
moneyColor[2]=config["Money color"]["3"].ToFloat();
moneyColor[3]=config["Money color"]["4"].ToFloat();

EspDistance=config["ESP Distance"].ToBool();
distanceColor[0]=config["Distance color"]["1"].ToFloat();
distanceColor[1]=config["Distance color"]["2"].ToFloat();
distanceColor[2]=config["Distance color"]["3"].ToFloat();
distanceColor[3]=config["Distance color"]["4"].ToFloat();

EspWeapon=config["ESP Weapon"].ToBool();
weaponColor[0]=config["Weapon color"]["1"].ToFloat();
weaponColor[1]=config["Weapon color"]["2"].ToFloat();
weaponColor[2]=config["Weapon color"]["3"].ToFloat();
weaponColor[3]=config["Weapon color"]["4"].ToFloat();

EspSkeleton=config["ESP Skeleton"].ToBool();
skeletonColor[0]=config["Skeleton color"]["1"].ToFloat();
skeletonColor[1]=config["Skeleton color"]["2"].ToFloat();
skeletonColor[2]=config["Skeleton color"]["3"].ToFloat();
skeletonColor[3]=config["Skeleton color"]["4"].ToFloat();

noFlash=config["Anti flash"].ToBool();
noSmoke=config["Anti smoke"].ToBool();
unityChams=config["Material chams"].ToBool();
unityChamsColor[0]=config["Material color"]["1"].ToFloat();
unityChamsColor[1]=config["Material color"]["2"].ToFloat();
unityChamsColor[2]=config["Material color"]["3"].ToFloat();
unityChamsColor[3]=config["Material color"]["4"].ToFloat();
materialGlossiness=config["_Glossiness"].ToFloat();
materialMetallic=config["_Metallic"].ToFloat();

fogEnable=config["Fog"].ToBool();
fogColor[0]=config["Fog color"]["1"].ToFloat();
fogColor[1]=config["Fog color"]["2"].ToFloat();
fogColor[2]=config["Fog color"]["3"].ToFloat();
fogColor[3]=config["Fog color"]["4"].ToFloat();
fogDist=config["Fog Distance"].ToFloat();

skyEnable=config["Sky"].ToBool();
skyColor[0]=config["Sky color"]["1"].ToFloat();
skyColor[1]=config["Sky color"]["2"].ToFloat();
skyColor[2]=config["Sky color"]["3"].ToFloat();
skyColor[3]=config["Sky color"]["4"].ToFloat();
skyRainbow=config["Sky Rainbow"].ToBool();

ThirdPerson=config["Third person"].ToBool();
thirdfloat=config["Third distance"].ToFloat();
noRecoil=config["Norecoil"].ToBool();
noSpread=config["Disable spread"].ToBool();

traceEnable=config["Player Tracer"].ToBool();
traceColor[0]=config["Trace color"]["1"].ToFloat();
traceColor[1]=config["Trace color"]["2"].ToFloat();
traceColor[2]=config["Trace color"]["3"].ToFloat();
traceColor[3]=config["Trace color"]["4"].ToFloat();
traceRainbow=config["Trace Rainbow"].ToBool();

infiniteJump=config["Infinity jump"].ToBool();
Jump=config["High jump"].ToBool();
JumpHeight=config["Jump height"].ToFloat();
wallWalking=config["Wall walking"].ToBool();

Speed=config["Speed hack"].ToBool();
SpeedHack=config["Speed value"].ToFloat();
Bhop=config["Bunny hope"].ToBool();
SpeedBhop=config["Bhop speed"].ToFloat();

HandsPosition=config["Custom Position"].ToBool();
HandsPos[0]=config["X"]["1"].ToFloat();
HandsPos[1]=config["Y"]["2"].ToFloat();
HandsPos[2]=config["Z"]["3"].ToFloat();

nightmode=config["Night Mode"].ToBool();
nightvalue=config["Night value"].ToFloat();

spinEnable=config["Spin Bot"].ToBool();
SpinYaw=config["Spin Bot Speed"].ToFloat();

Swaston=config["Swaston"].ToBool();
swastonColor[0]=config["Swaston color"]["1"].ToFloat();
swastonColor[1]=config["Swaston color"]["2"].ToFloat();
swastonColor[2]=config["Swaston color"]["3"].ToFloat();
swastonColor[3]=config["Swaston color"]["4"].ToFloat();

g_CT=config["СКИНЫ"]["Нож"]["CT"].ToInt();
g_TT=config["СКИНЫ"]["Нож"]["TER"].ToInt();

g_KNIFECT=config["СКИНЫ"]["Скины на ножи"]["KNIFECT"].ToInt();
g_KNIFETER=config["СКИНЫ"]["Скины на ножи"]["KNIFETER"].ToInt();
g_BAYONETM9=config["СКИНЫ"]["Скины на ножи"]["BAYONETM9"].ToInt();
g_BOWIE=config["СКИНЫ"]["Скины на ножи"]["BOWIE"].ToInt();
g_BUTTERFLY=config["СКИНЫ"]["Скины на ножи"]["BUTTERFLY"].ToInt();
g_FLIP=config["СКИНЫ"]["Скины на ножи"]["FLIP"].ToInt();
g_GUT=config["СКИНЫ"]["Скины на ножи"]["GUT"].ToInt();
g_KARAMBIT=config["СКИНЫ"]["Скины на ножи"]["KARAMBIT"].ToInt();
g_NOMAD=config["СКИНЫ"]["Скины на ножи"]["NOMAD"].ToInt();
g_SDAGGER=config["СКИНЫ"]["Скины на ножи"]["SDAGGER"].ToInt();

g_AK47=config["СКИНЫ"]["Скины на оружия"]["AK47"].ToInt();
g_AN94=config["СКИНЫ"]["Скины на оружия"]["AN94"].ToInt();
g_AUG=config["СКИНЫ"]["Скины на оружия"]["AUG"].ToInt();
g_AWP=config["СКИНЫ"]["Скины на оружия"]["AWP"].ToInt();
g_BERETTA92=config["СКИНЫ"]["Скины на оружия"]["BERETTA92"].ToInt();
g_COLTM1911=config["СКИНЫ"]["Скины на оружия"]["COLTM1911"].ToInt();
g_CZ75=config["СКИНЫ"]["Скины на оружия"]["CZ75"].ToInt();
g_CZ75AUTO=config["СКИНЫ"]["Скины на оружия"]["CZ75AUTO"].ToInt();
g_DAEWOOK2=config["СКИНЫ"]["Скины на оружия"]["DAEWOOK2"].ToInt();
g_DEAGLE=config["СКИНЫ"]["Скины на оружия"]["DEAGLE"].ToInt();
g_FAMAS=config["СКИНЫ"]["Скины на оружия"]["FAMAS"].ToInt();
g_FIVESEVEN=config["СКИНЫ"]["Скины на оружия"]["FIVESEVEN"].ToInt();
g_FMG9=config["СКИНЫ"]["Скины на оружия"]["FMG9"].ToInt();
g_G3SG1=config["СКИНЫ"]["Скины на оружия"]["G3SG1"].ToInt();
g_GALIL=config["СКИНЫ"]["Скины на оружия"]["GALIL"].ToInt();
g_GLOCK18=config["СКИНЫ"]["Скины на оружия"]["GLOCK18"].ToInt();
g_HK416=config["СКИНЫ"]["Скины на оружия"]["HK416"].ToInt();
g_IWIJERICHO941=config["СКИНЫ"]["Скины на оружия"]["IWIJERICHO941"].ToInt();
g_KRISSVECTOR=config["СКИНЫ"]["Скины на оружия"]["KRISSVECTOR"].ToInt();
g_KTECKSG=config["СКИНЫ"]["Скины на оружия"]["KTECKSG"].ToInt();
g_M249=config["СКИНЫ"]["Скины на оружия"]["M249"].ToInt();
g_M4A1=config["СКИНЫ"]["Скины на оружия"]["M4A1"].ToInt();
g_M4A4=config["СКИНЫ"]["Скины на оружия"]["M4A4"].ToInt();
g_M60=config["СКИНЫ"]["Скины на оружия"]["M60"].ToInt();
g_MAC10=config["СКИНЫ"]["Скины на оружия"]["MAC10"].ToInt();
g_MGPK=config["СКИНЫ"]["Скины на оружия"]["MGPK"].ToInt();
g_MICROUZI=config["СКИНЫ"]["Скины на оружия"]["MICROUZI"].ToInt();
g_MP5=config["СКИНЫ"]["Скины на оружия"]["MP5"].ToInt();
g_MP5SD=config["СКИНЫ"]["Скины на оружия"]["MP5SD"].ToInt();
g_MP7=config["СКИНЫ"]["Скины на оружия"]["MP7"].ToInt();
g_MP9=config["СКИНЫ"]["Скины на оружия"]["MP9"].ToInt();
g_NEGEV=config["СКИНЫ"]["Скины на оружия"]["NEGEV"].ToInt();
g_NEOSTEAD=config["СКИНЫ"]["Скины на оружия"]["NEOSTEAD"].ToInt();
g_NOVA=config["СКИНЫ"]["Скины на оружия"]["NOVA"].ToInt();
g_P2000=config["СКИНЫ"]["Скины на оружия"]["P2000"].ToInt();
g_P90=config["СКИНЫ"]["Скины на оружия"]["P90"].ToInt();
g_QBZ95=config["СКИНЫ"]["Скины на оружия"]["QBZ95"].ToInt();
g_R8REVOLVER=config["СКИНЫ"]["Скины на оружия"]["R8REVOLVER"].ToInt();
g_SCARSSR=config["СКИНЫ"]["Скины на оружия"]["SCARSSR"].ToInt();
g_SIG550S=config["СКИНЫ"]["Скины на оружия"]["SIG550S"].ToInt();
g_SIG556=config["СКИНЫ"]["Скины на оружия"]["SIG556"].ToInt();
g_SIGP250=config["СКИНЫ"]["Скины на оружия"]["SIGP250"].ToInt();
g_SSCOUT=config["СКИНЫ"]["Скины на оружия"]["SSCOUT"].ToInt();
g_SSG08=config["СКИНЫ"]["Скины на оружия"]["SSG08"].ToInt();
g_SV98=config["СКИНЫ"]["Скины на оружия"]["SV98"].ToInt();
g_TAR21=config["СКИНЫ"]["Скины на оружия"]["TAR21"].ToInt();
g_TEC9=config["СКИНЫ"]["Скины на оружия"]["TEC9"].ToInt();
g_UMP=config["СКИНЫ"]["Скины на оружия"]["UMP"].ToInt();
g_USP=config["СКИНЫ"]["Скины на оружия"]["USP"].ToInt();
g_VINTOREZ=config["СКИНЫ"]["Скины на оружия"]["VINTOREZ"].ToInt();
g_VITYAZ=config["СКИНЫ"]["Скины на оружия"]["VITYAZ"].ToInt();
g_WALTHERP99=config["СКИНЫ"]["Скины на оружия"]["WALTHERP99"].ToInt();
g_XM1014=config["СКИНЫ"]["Скины на оружия"]["XM1014"].ToInt();

Watermark_Bool=config["Show watermark"].ToBool();
antikick_keybind=config["AK-Keybind"].ToBool();
noKick=config["Anti kick"].ToBool();;
}

void SaveConfig(const int NUMBER) {
JSON config;

config["Silent aim"]=silentAim;
config["Aim Silent"]=silentEnable;
config["Auto fire"]=autofire;
config["HitBox - Head"]=silentHead;
config["Draw fov"]=fovEnable;
config["Radius fov"]=fovRadius;

config["Fov Defualt"]=fovDefualt;
config["Fov Outline"]=fovOutline;
config["Anti Aim"]=AntiAim;
config["Mode: Spin"]=AA_Spin;
config["Mode: Spin Speed"]=AA_Speed;
config["Pitch: Spin Defualt"]=AA_SpinDefualt;
config["Pitch: Spin Up"]=AA_SpinUp;

config["ESP Line Top"]=EspLineTop;
config["ESP Line Center"]=EspLineCenter;
config["ESP Line Bottom"]=EspLineBottom;
config["Line color"]["1"]=lineColor[0];
config["Line color"]["2"]=lineColor[1];
config["Line color"]["3"]=lineColor[2];
config["Line color"]["4"]=lineColor[3];

config["ESP Box"]=EspBox;
config["Box color"]["1"]=rectColor[0];
config["Box color"]["2"]=rectColor[1];
config["Box color"]["3"]=rectColor[2];
config["Box color"]["4"]=rectColor[3];

config["ESP Gradient"]=EspGradient;
config["Grad color"]["1"]=GradientColor[0];
config["Grad color"]["2"]=GradientColor[1];
config["Grad color"]["3"]=GradientColor[2];
config["Grad color"]["4"]=GradientColor[3];

config["ESP Health"]=EspHealth;
config["Health color"]["1"]=HealthColor[0];
config["Health color"]["2"]=HealthColor[1];
config["Health color"]["3"]=HealthColor[2];
config["Health color"]["4"]=HealthColor[3];

config["ESP Armor"]=EspArmor;
config["Armor color"]["1"]=ArmorColor[0];
config["Armor color"]["2"]=ArmorColor[1];
config["Armor color"]["3"]=ArmorColor[2];
config["Armor color"]["4"]=ArmorColor[3];

config["ESP Name"]=EspNickname;
config["Name color"]["1"]=nicknameColor[0];
config["Name color"]["2"]=nicknameColor[1];
config["Name color"]["3"]=nicknameColor[2];
config["Name color"]["4"]=nicknameColor[3];

config["ESP Money"]=EspMoney;
config["Money color"]["1"]=moneyColor[0];
config["Money color"]["2"]=moneyColor[1];
config["Money color"]["3"]=moneyColor[2];
config["Money color"]["4"]=moneyColor[3];

config["ESP Distance"]=EspDistance;
config["Distance color"]["1"]=distanceColor[0];
config["Distance color"]["2"]=distanceColor[1];
config["Distance color"]["3"]=distanceColor[2];
config["Distance color"]["4"]=distanceColor[3];

config["ESP Weapon"]=EspWeapon;
config["Weapon color"]["1"]=weaponColor[0];
config["Weapon color"]["2"]=weaponColor[1];
config["Weapon color"]["3"]=weaponColor[2];
config["Weapon color"]["4"]=weaponColor[3];

config["ESP Skeleton"]=EspSkeleton;
config["Skeleton color"]["1"]=skeletonColor[0];
config["Skeleton color"]["2"]=skeletonColor[1];
config["Skeleton color"]["3"]=skeletonColor[2];
config["Skeleton color"]["4"]=skeletonColor[3];

config["Anti flash"]=noFlash;
config["Anti smoke"]=noSmoke;

config["Material chams"]=unityChams;
config["Material color"]["1"]=unityChamsColor[0];
config["Material color"]["2"]=unityChamsColor[1];
config["Material color"]["3"]=unityChamsColor[2];
config["Material color"]["4"]=unityChamsColor[3];
config["_Glossiness"]=materialGlossiness;
config["_Metallic"]=materialMetallic;

config["Fog"]=fogEnable;
config["Fog color"]["1"]=fogColor[0];
config["Fog color"]["2"]=fogColor[1];
config["Fog color"]["3"]=fogColor[2];
config["Fog color"]["4"]=fogColor[3];
config["Fog Distance"]=fogDist;

config["Sky"]=skyEnable;
config["Sky color"]["1"]=skyColor[0];
config["Sky color"]["2"]=skyColor[1];
config["Sky color"]["3"]=skyColor[2];
config["Sky color"]["4"]=skyColor[3];
config["Sky Rainbow"]=skyRainbow;

config["Third person"]=ThirdPerson;
config["Third distance"]=thirdfloat;
config["Norecoil"]=noRecoil;
config["Disable spread"]=noSpread;
config["Infinity jump"]=infiniteJump;
config["High jump"]=Jump;
config["Jump height"]=JumpHeight;
config["Wall walking"]=wallWalking;
config["Speed hack"]=Speed;
config["Speed value"]=SpeedHack;
config["Bunny hope"]=Bhop;
config["Bhop speed"]=SpeedBhop;

config["Spin Bot"]=spinEnable;
config["Spin Bot Speed"]=SpinYaw;

config["Player Tracer"]=traceEnable;
config["Trace color"]["1"]=traceColor[0];
config["Trace color"]["2"]=traceColor[1];
config["Trace color"]["3"]=traceColor[2];
config["Trace color"]["4"]=traceColor[3];
config["Trace Rainbow"]=traceRainbow;

config["Custom Position"]=HandsPosition;
config["X"]["1"]=HandsPos[0];
config["Y"]["2"]=HandsPos[1];
config["Z"]["3"]=HandsPos[2];

config["Night Mode"]=nightmode;
config["Night value"]=nightvalue;

config["Swaston"]=Swaston;
config["Swaston color"]["1"]=swastonColor[0];
config["Swaston color"]["2"]=swastonColor[1];
config["Swaston color"]["3"]=swastonColor[2];
config["Swaston color"]["4"]=swastonColor[3];

config["СКИНЫ"]["Нож"]["CT"]=g_CT;
config["СКИНЫ"]["Нож"]["TER"]=g_TT;

config["СКИНЫ"]["Скины на ножи"]["KNIFECT"]=g_KNIFECT;
config["СКИНЫ"]["Скины на ножи"]["KNIFETER"]=g_KNIFETER;
config["СКИНЫ"]["Скины на ножи"]["BAYONETM9"]=g_BAYONETM9;
config["СКИНЫ"]["Скины на ножи"]["BOWIE"]=g_BOWIE;
config["СКИНЫ"]["Скины на ножи"]["BUTTERFLY"]=g_BUTTERFLY;
config["СКИНЫ"]["Скины на ножи"]["FLIP"]=g_FLIP;
config["СКИНЫ"]["Скины на ножи"]["GUT"]=g_GUT;
config["СКИНЫ"]["Скины на ножи"]["KARAMBIT"]=g_KARAMBIT;
config["СКИНЫ"]["Скины на ножи"]["NOMAD"]=g_NOMAD;
config["СКИНЫ"]["Скины на ножи"]["SDAGGER"]=g_SDAGGER;

config["СКИНЫ"]["Скины на оружия"]["AK47"]=g_AK47;
config["СКИНЫ"]["Скины на оружия"]["AN94"]=g_AN94;
config["СКИНЫ"]["Скины на оружия"]["AUG"]=g_AUG;
config["СКИНЫ"]["Скины на оружия"]["AWP"]=g_AWP;
config["СКИНЫ"]["Скины на оружия"]["BERETTA92"]=g_BERETTA92;
config["СКИНЫ"]["Скины на оружия"]["COLTM1911"]=g_COLTM1911;
config["СКИНЫ"]["Скины на оружия"]["CZ75"]=g_CZ75;
config["СКИНЫ"]["Скины на оружия"]["CZ75AUTO"]=g_CZ75AUTO;
config["СКИНЫ"]["Скины на оружия"]["DAEWOOK2"]=g_DAEWOOK2;
config["СКИНЫ"]["Скины на оружия"]["DEAGLE"]=g_DEAGLE;
config["СКИНЫ"]["Скины на оружия"]["FAMAS"]=g_FAMAS;
config["СКИНЫ"]["Скины на оружия"]["FIVESEVEN"]=g_FIVESEVEN;
config["СКИНЫ"]["Скины на оружия"]["FMG9"]=g_FMG9;
config["СКИНЫ"]["Скины на оружия"]["G3SG1"]=g_G3SG1;
config["СКИНЫ"]["Скины на оружия"]["GALIL"]=g_GALIL;
config["СКИНЫ"]["Скины на оружия"]["GLOCK18"]=g_GLOCK18;
config["СКИНЫ"]["Скины на оружия"]["HK416"]=g_HK416;
config["СКИНЫ"]["Скины на оружия"]["IWIJERICHO941"]=g_IWIJERICHO941;
config["СКИНЫ"]["Скины на оружия"]["KRISSVECTOR"]=g_KRISSVECTOR;
config["СКИНЫ"]["Скины на оружия"]["KTECKSG"]=g_KTECKSG;
config["СКИНЫ"]["Скины на оружия"]["M249"]=g_M249;
config["СКИНЫ"]["Скины на оружия"]["M4A1"]=g_M4A1;
config["СКИНЫ"]["Скины на оружия"]["M4A4"]=g_M4A4;
config["СКИНЫ"]["Скины на оружия"]["M60"]=g_M60;
config["СКИНЫ"]["Скины на оружия"]["MAC10"]=g_MAC10;
config["СКИНЫ"]["Скины на оружия"]["MGPK"]=g_MGPK;
config["СКИНЫ"]["Скины на оружия"]["MICROUZI"]=g_MICROUZI;
config["СКИНЫ"]["Скины на оружия"]["MP5"]=g_MP5;
config["СКИНЫ"]["Скины на оружия"]["MP5SD"]=g_MP5SD;
config["СКИНЫ"]["Скины на оружия"]["MP7"]=g_MP7;
config["СКИНЫ"]["Скины на оружия"]["MP9"]=g_MP9;
config["СКИНЫ"]["Скины на оружия"]["NEGEV"]=g_NEGEV;
config["СКИНЫ"]["Скины на оружия"]["NEOSTEAD"]=g_NEOSTEAD;
config["СКИНЫ"]["Скины на оружия"]["NOVA"]=g_NOVA;
config["СКИНЫ"]["Скины на оружия"]["P2000"]=g_P2000;
config["СКИНЫ"]["Скины на оружия"]["P90"]=g_P90;
config["СКИНЫ"]["Скины на оружия"]["QBZ95"]=g_QBZ95;
config["СКИНЫ"]["Скины на оружия"]["R8REVOLVER"]=g_R8REVOLVER;
config["СКИНЫ"]["Скины на оружия"]["SCARSSR"]=g_SCARSSR;
config["СКИНЫ"]["Скины на оружия"]["SIG550S"]=g_SIG550S;
config["СКИНЫ"]["Скины на оружия"]["SIG556"]=g_SIG556;
config["СКИНЫ"]["Скины на оружия"]["SIGP250"]=g_SIGP250;
config["СКИНЫ"]["Скины на оружия"]["SSCOUT"]=g_SSCOUT;
config["СКИНЫ"]["Скины на оружия"]["SSG08"]=g_SSG08;
config["СКИНЫ"]["Скины на оружия"]["SV98"]=g_SV98;
config["СКИНЫ"]["Скины на оружия"]["TAR21"]=g_TAR21;
config["СКИНЫ"]["Скины на оружия"]["TEC9"]=g_TEC9;
config["СКИНЫ"]["Скины на оружия"]["UMP"]=g_UMP;
config["СКИНЫ"]["Скины на оружия"]["USP"]=g_USP;
config["СКИНЫ"]["Скины на оружия"]["VINTOREZ"]=g_VINTOREZ;
config["СКИНЫ"]["Скины на оружия"]["VITYAZ"]=g_VITYAZ;
config["СКИНЫ"]["Скины на оружия"]["WALTHERP99"]=g_WALTHERP99;
config["СКИНЫ"]["Скины на оружия"]["XM1014"]=g_XM1014;

config["Show watermark"]=Watermark_Bool;
config["AK-Keybind"]=antikick_keybind;
config["Anti kick"]=noKick;

string dump(config.dump());
ofstream file(WAY_FOR_CFG + NAME_CFG + to_string(NUMBER) + TYPE_CFG);
file.write(dump.c_str(), dump.size());
}
