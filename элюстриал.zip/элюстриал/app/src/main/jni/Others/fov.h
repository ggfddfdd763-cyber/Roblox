void DrawFov() {
if (drawsilentfov) {
        ImGui::Begin("##dsdsfds", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoMouseInputs);
        auto draw = ImGui::GetBackgroundDrawList();
        draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), silentaimfov,
                        ImGui::ColorConvertFloat4ToU32(silentaimclr), 100, 1.5f);
        ImGui::End();
    }
    if (drawautofirefov) {
        ImGui::Begin("##aalalls", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoMouseInputs);
        auto draw = ImGui::GetBackgroundDrawList();
        draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), autofirefov,
                        ImGui::ColorConvertFloat4ToU32(autofirefov_clr), 100, 1.5f);
        ImGui::End();
    }
    if (drawaimbotfov) {
        ImGui::Begin("##kdjsss", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoMouseInputs);
        auto draw = ImGui::GetBackgroundDrawList();
        draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), aimbotfov,
                        ImGui::ColorConvertFloat4ToU32(aimfovcolor), 100, 1.5f);
        ImGui::End();
    }
	}
