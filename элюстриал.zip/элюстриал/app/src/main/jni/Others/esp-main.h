void DrawSkeleton(void* player, ImColor color) {
if (player) {
bool PosHeadUpC,PosHeadC,PosRightHandC,PosLeftHandC,PosNeckC,PosHipsC,PosleftUpperArmC,leftLowerArmC,rightUpperArmC,rightLowerArmC,leftUpperLegC,leftLowerLegC,rightUpperLegC,rightLowerLegC,rightUpperLegDownC,leftUpperLegDownC;
ImVec2 PosHeadUp = world2screen_c(GetPlayerHead(player) + Vector3(0, 0.3f, 0), PosHeadUpC);
ImVec2 PosHead = world2screen_c(GetPlayerHead(player), PosHeadC);
ImVec2 PosRightHand = world2screen_c(GetPlayerRightHand(player), PosRightHandC);
ImVec2 PosLeftHand = world2screen_c(GetPlayerLeftHand(player), PosLeftHandC);
ImVec2 PosNeck = world2screen_c(GetPlayerNeck(player), PosNeckC);
ImVec2 PosHips = world2screen_c(GetPlayerHip(player), PosHipsC);
ImVec2 PosleftUpperArm = world2screen_c(GetPlayerleftUpperArm(player), PosleftUpperArmC);
ImVec2 leftLowerArm = world2screen_c(GetPlayerleftLowerArm(player), leftLowerArmC);
ImVec2 rightUpperArm = world2screen_c(GetPlayerrightUpperArm(player), rightUpperArmC);
ImVec2 rightLowerArm = world2screen_c(GetPlayerrightLowerArm(player), rightLowerArmC);
ImVec2 leftUpperLeg = world2screen_c(GetPlayerleftUpperLeg(player), leftUpperLegC);
ImVec2 leftLowerLeg = world2screen_c(GetPlayerleftLowerLeg(player), leftLowerLegC);
ImVec2 rightUpperLeg = world2screen_c(GetPlayerrightUpperLeg(player), rightUpperLegC);
ImVec2 rightLowerLeg = world2screen_c(GetPlayerrightLowerLeg(player), rightLowerLegC);
ImVec2 rightUpperLegDown = world2screen_c(GetPlayerrightLowerLeg(player) - Vector3(0, 0.1f, 0), rightUpperLegDownC);
ImVec2 leftUpperLegDown = world2screen_c(GetPlayerleftLowerLeg(player) - Vector3(0, 0.1f, 0), leftUpperLegDownC);
if (PosHeadUpC && PosHeadC && PosRightHandC && PosLeftHandC && PosNeckC && PosHipsC && PosleftUpperArmC && leftLowerArmC && rightUpperArmC && rightLowerArmC && leftUpperLegC && leftLowerLegC && rightUpperLegC && rightLowerLegC && rightUpperLegDownC && leftUpperLegDownC) {
ImGui::GetBackgroundDrawList()->AddLine(PosHead, PosNeck,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(PosNeck, PosHips,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(PosNeck,PosleftUpperArm,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(PosleftUpperArm,leftLowerArm,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(leftLowerArm,PosLeftHand,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(PosNeck, rightUpperArm,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(rightUpperArm,rightLowerArm,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(rightLowerArm,PosRightHand,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(PosHips, leftUpperLeg,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(leftUpperLeg,leftLowerLeg,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(PosHips, rightUpperLeg,color, 2);
ImGui::GetBackgroundDrawList()->AddLine(rightUpperLeg,rightLowerLeg,color, 2);
ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(PosHead.x, PosHead.y - ((PosHead.y - PosHeadUp.y) * 0.8) / 2),((PosHead.y - PosHeadUp.y) * 0.8) / 2,color, 30, 2);
}
}
}
void DrawChinaHat(Vector3 pos, float segments, float radius, ImColor color, ImColor lcolor) {
ImVec2 toppos = world2screen_i(pos + Vector3(0,radius,0));
for (float i = 0; i < segments; i++) {
if (i < segments) {
Vector3 pos1 = Vector3(pos.x + radius * cos(i * (M_PI * 2) / segments),pos.y,pos.z + radius * sin(i * (M_PI * 2) / segments));
Vector3 pos2 = Vector3(pos.x + radius * cos((i + 1) * (M_PI * 2) / segments) ,pos.y,pos.z + radius * sin((i + 1) * (M_PI * 2) / segments));
static bool checker1;   
static bool checker2;
ImVec2 vPos = world2screen_c(pos1, checker1);
ImVec2 vNextPos = world2screen_c(pos2, checker2);
if (checker1 && checker2) {
ImGui::GetBackgroundDrawList()->AddLine(vPos, vNextPos, lcolor, 3);
ImGui::GetBackgroundDrawList()->AddTriangleFilled(toppos, vPos, vNextPos, color);
}
}
}
}

void DrawESP() {
auto drawlist = ImGui::GetBackgroundDrawList();
		clearPlayers();
	for (int i = 0; i < players.size(); i++) {
        if (players[i] != NULL) {
            void *Player = players[i];			
			Vector3 playerpos = get_position(get_transform(Player));
            Vector3 lower_pos = WorldToScreenPoint(get_camera(), Vector3(playerpos.x, playerpos.y, playerpos.z));          
			Vector3 playerpos_up = get_position(get_transform(Player)) + Vector3(0, 1.9f, 0);
			Vector3 upper_pos = WorldToScreenPoint(get_camera(), Vector3(playerpos_up.x, playerpos_up.y, playerpos_up.z));		
			Vector3 posup = get_position(get_transform(Player))+Vector3(0,1.9f,0);
			Vector3 posdown = get_position(get_transform(Player));
			Vector3 posuponscr = WorldToScreenPoint(get_camera(),posup);
			Vector3 posdownonscr = WorldToScreenPoint(get_camera(),posdown);
			int Height = upper_pos.y - lower_pos.y;
			int Width = Height * 0.6;
			auto render = ImGui::GetBackgroundDrawList();
			auto weap = GetWeaponID(Player);
            std::string weaps = "null";
            if (weap) weaps = weap;
            std::transform(weaps.begin(), weaps.end(), weaps.begin(), ::tolower);
            std::string wpn = weaps;
			auto pos = get_position(get_transform(Player));
            static float hatalpha = 0.200f;
            static float hatradius = 0.25f;
            static float hatsegments = 10.f;
            static float skeletoncolor[] = {1,1,1};
            static ImVec4 chinahat = ImColor(255,255,255);
            auto chinacolor = chinahat;
			static bool checker1,checker2;
            static bool visible;
			void *camera = get_camera();
			Vector3 MeshHead = get_position(get_transform(Player))+Vector3(0, 1.9f, 0);
            Vector3 HeadPos = WorldToScreenPoint(camera, Vector3(MeshHead.x ,MeshHead.y, MeshHead.z));
			
			if (upper_pos.z > 1.0f) {
			    if (EspLine) {
			      ImGui::GetBackgroundDrawList()->AddLine(ImVec2(glWidth / 2, glHeight), ImVec2(lower_pos.x, glHeight - lower_pos.y), ImGui::ColorConvertFloat4ToU32(ImVec4(line)), 2);
			      ImGui::GetBackgroundDrawList()->AddLine(ImVec2(glWidth / 2, glHeight), ImVec2(lower_pos.x, glHeight - lower_pos.y), ImGui::ColorConvertFloat4ToU32(ImVec4(line)), 1);
			    }
			    if (EspBox) {
			      ImGui::GetBackgroundDrawList()->AddRect(ImVec2(upper_pos.x - Width/2, glHeight - upper_pos.y), ImVec2(upper_pos.x + Width/2, glHeight - upper_pos.y + Height), ImGui::ColorConvertFloat4ToU32(ImVec4(box)), 0, 0, 2);
			      ImGui::GetBackgroundDrawList()->AddRect(ImVec2(upper_pos.x - Width/2, glHeight - upper_pos.y), ImVec2(upper_pos.x + Width/2, glHeight - upper_pos.y + Height), ImGui::ColorConvertFloat4ToU32(ImVec4(box)), 0, 0, 1);
            	}
				if (EspGradient) {
            	  ImGui::GetBackgroundDrawList()->AddRectFilledMultiColor(ImVec2(upper_pos.x - Width/2, glHeight - upper_pos.y), ImVec2(upper_pos.x + Width/2, glHeight - upper_pos.y + Height),
              	  ImColor(0, 0, 0, 0),
            	  ImColor(0, 0, 0, 0),
            	  ImColor(gradient),
				  ImColor(gradient));
            	}
                if (EspName) {
				monoString *isPlayerName = get_name(get_photon(Player));
				ImGui::PushFont(SkeetNormal);					
				render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(isPlayerName->get_string().c_str()).x/2)+1.8f,(glHeight-posuponscr.y- 20)+1.8f), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), isPlayerName->get_string().c_str());
				render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(isPlayerName->get_string().c_str()).x/2),glHeight-posuponscr.y- 20), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), isPlayerName->get_string().c_str());
				ImGui::PopFont();
				}
			 	if(EspDistance){
				Vector3 mypos = get_position(get_transform(get_camera()));
				int DistanceTo=get_3D_Distance(mypos.x, mypos.y, mypos.z, posup.x, posup.y, posup.z);
				ImGui::PushFont(SkeetSmall);
				render->AddText(ImVec2((posuponscr.x+5+Width/2)-1,(glHeight-posuponscr.y-2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(DistanceTo)+"M").c_str());
				render->AddText(ImVec2((posuponscr.x+5+Width/2)-1,(glHeight-posuponscr.y-2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(DistanceTo)+"M").c_str());
				render->AddText(ImVec2((posuponscr.x+5+Width/2)+1,(glHeight-posuponscr.y-2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(DistanceTo)+"M").c_str());
			    render->AddText(ImVec2((posuponscr.x+5+Width/2)+1,(glHeight-posuponscr.y-2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(DistanceTo)+"M").c_str());
				render->AddText(ImVec2(posuponscr.x+5+Width/2,glHeight-posuponscr.y-2), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), (std::to_string(DistanceTo)+"M").c_str());
			    ImGui::PopFont();
				}
				if (get_photon(Player)) {
      int espHealth = GetHealth(get_photon(Player));
      float healthPercent = espHealth/100.f;
      if (EspHealth) {
       const float hWidth = 6.0f;
       const float hOffset = 8.0f;
       float hHeight = Height * healthPercent;
       drawlist->AddRectFilled(
        ImVec2(HeadPos.x - Width/2 - hOffset, glHeight - HeadPos.y),
        ImVec2(HeadPos.x - Width/2 - hOffset + hWidth, glHeight - HeadPos.y + Height),
        ImColor(0, 0, 0, 255)
       );
       drawlist->AddRectFilled(
        ImVec2(HeadPos.x - Width/2 - hOffset, glHeight - HeadPos.y + (Height - hHeight)),
        ImVec2(HeadPos.x - Width/2 - hOffset + hWidth, glHeight - HeadPos.y + Height),
        ImColor(0, 255, 0, 255)
       );
      }
				if(EspSkeleton){
DrawSkeleton(Player,ImColor(skeletoncolor[0],skeletoncolor[1],skeletoncolor[2],1.0f));
}
if (EspChinaHat) {
DrawChinaHat(Vector3(get_position(get_head(Player)).x, get_position(get_head(Player)).y + 0.22f, get_position(get_head(Player)).z), hatsegments, hatradius, ImVec4(chinacolor.x, chinacolor.y, chinacolor.z, hatalpha), chinacolor);
}
if(EspWeapon){
ImGui::PushFont(Pixel);
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(wpn.c_str()).x/2)-1,(glHeight-posdownonscr.y)+-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(wpn.c_str()).x/2)-1,(glHeight-posdownonscr.y)+-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(wpn.c_str()).x/2)+1,(glHeight-posdownonscr.y)+-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(wpn.c_str()).x/2)+1,(glHeight-posdownonscr.y)+-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), wpn.c_str());
render->AddText(ImVec2(posuponscr.x-ImGui::CalcTextSize(wpn.c_str()).x/2,glHeight-posdownonscr.y+-1), ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)), wpn.c_str());
ImGui::PopFont();
}
if(EspWeaponIcon){
int weaponid = GetWeaponID(Player);
std::string weapng = weaptofont[weaponid];
ImGui::PushFont(weapon_font);
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(weapng.c_str()).x/2)-1,(glHeight-posdownonscr.y+-1+ImGui::CalcTextSize(weapng.c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(weapng.c_str()).x/2)-1,(glHeight-posdownonscr.y+-1+ImGui::CalcTextSize(weapng.c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(weapng.c_str()).x/2)+1,(glHeight-posdownonscr.y+-1+ImGui::CalcTextSize(weapng.c_str()).y/2)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
render->AddText(ImVec2((posuponscr.x-ImGui::CalcTextSize(weapng.c_str()).x/2)+1,(glHeight-posdownonscr.y+-1+ImGui::CalcTextSize(weapng.c_str()).y/2)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), weapng.c_str());
render->AddText(ImVec2(posuponscr.x-ImGui::CalcTextSize(weapng.c_str()).x/2,glHeight-posdownonscr.y+-1+ImGui::CalcTextSize(weapng.c_str()).y/2), ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 1)), weapng.c_str());
ImGui::PopFont();
}
if(EspMoney){
int Money = GetMoney(get_photon(pl));
ImGui::PushFont(Pixel);
render->AddText(ImVec2((posuponscr.x+5+width/2)-1,(glHeight-posuponscr.y+12)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Money)+"$").c_str());
render->AddText(ImVec2((posuponscr.x+5+width/2)-1,(glHeight-posuponscr.y+12)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Money)+"$").c_str());
render->AddText(ImVec2((posuponscr.x+5+width/2)+1,(glHeight-posuponscr.y+12)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Money)+"$").c_str());
render->AddText(ImVec2((posuponscr.x+5+width/2)+1,(glHeight-posuponscr.y+12)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Money)+"$").c_str());
render->AddText(ImVec2(posuponscr.x+5+width/2,glHeight-posuponscr.y+12), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), (std::to_string(Money)+"$").c_str());
ImGui::PopFont();
}
if(EspPing){
int Ping = GetPing(get_photon(Player));
ImGui::PushFont(Pixel);
render->AddText(ImVec2((posuponscr.x+5+Width/2)-1,(glHeight-posuponscr.y+27)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Ping)+"ms").c_str());
render->AddText(ImVec2((posuponscr.x+5+Width/2)-1,(glHeight-posuponscr.y+27)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Ping)+"ms").c_str());
render->AddText(ImVec2((posuponscr.x+5+Width/2)+1,(glHeight-posuponscr.y+27)+1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Ping)+"ms").c_str());
render->AddText(ImVec2((posuponscr.x+5+Width/2)+1,(glHeight-posuponscr.y+27)-1), ImGui::ColorConvertFloat4ToU32(ImVec4(0,0,0, 1)), (std::to_string(Ping)+"ms").c_str());
render->AddText(ImVec2(posuponscr.x+5+Width/2,glHeight-posuponscr.y+27), ImGui::ColorConvertFloat4ToU32(ImVec4(1,1,1, 1)), (std::to_string(Ping)+"ms").c_str());
ImGui::PopFont();
}
if (EspPlayerCircle) {
static bool visible = true;
static float t = 0.0f;
if (visible) {
t += ImGui::GetIO().DeltaTime;
} else {
t -= ImGui::GetIO().DeltaTime;
}
if (t > 1.0f) {
t = 1.0f;
visible = false;
} else if (t < 0.0f) {
t = 0.0f;
visible = true;
}
ImVec4 color = ImVec4(1.0f, 1.0f, 1.0f, t);
for (int i = 0; i < 100; i++) {
Vector3 pos1 = Vector3(float((double) pos.x + 1 * cos((double) i * (PI * 2) / (double) 100)), float((double) pos.y), float((double) pos.z + 1 * sin((double) i * (PI * 2) / (double) 100)));
Vector3 pos2 = Vector3(float((double) pos.x + 1 * cos((double) (i + 1) * (PI * 2) / (double) 100)), float((double) pos.y), float((double) pos.z + 1 * sin((double) (i + 1) * (PI * 2) / (double) 100)));
ImVec2 ScreenPos1 = world2screen_c(pos1, checker1);
ImVec2 ScreenPos2 = world2screen_c(pos2, checker2);
if (checker1 && checker2) {
ImGui::GetBackgroundDrawList()->AddLine(ImVec2(ScreenPos1.x, ScreenPos1.y), ImVec2(ScreenPos2.x, ScreenPos2.y), ImColor(color), 2);
}
}}}}}}}
