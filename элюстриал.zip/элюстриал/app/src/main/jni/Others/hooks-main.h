








// PLAYERS // PLAYERS // PLAYERS // PLAYERS
void *aimedplayer = nullptr;
std::vector<void*> players;
void *enemy = nullptr;
void *me = nullptr;

/* INSTANCES */
void* chatinstance;
void* grenade_instance;

/*  This is needed for this bullshit to work */
monoString *(*il2cpp_string_new)(const char *str);

void initDlsymHooks(const char *name) {
    void *handle = dlopen_ex(name, 0);
    while (!handle) {
        handle = dlopen_ex(name, 0);
        sleep(1);
    }
    
    il2cpp_string_new = (monoString *(*)(const char *)) dlsym_ex(handle, oxorany("il2cpp_string_new"));
}

// PATCHES // PATCHES // PATCHES // PATCHES // PATCHES
struct My_Patches {
    MemoryPatch movebef, infdrop, invis, fastboom, friendly ;
} hexPatch;

// VARIABLES // VARIABLES // VARIABLES // VARIABLES
Quaternion PlayerLook;
void* atu;
Vector3 flypos;
namespace antiaim {
   bool enable;
   bool aastatic, aajitter;
   float x, y, z = 0.0f;
   bool randomrotation;
   float aaspeed = 10.0f;
}
const char* grenades[] = { 
   oxorany("HE"), oxorany("Smoke"), oxorany("Flash") 
};
bool thirdperson, leftarm, norecoil, infammo, ragdoll, respawnhack, airjump, defuseanywhere, wallshot, firerate, dmghack, onlyhead, godmode, fastknife, fastbomb, friendlyfire, nuke, nuke_me, nuke_enemy, anti_grenade, movebeforetimer, infinitydrops, invisible, fastdefuse, autowin_ct, autowin_tr, telekill, masskill, underground, insky, nopenetration, noclip, speed_hack, bhop, hands_pos, spam_chat, bighead, infinitegrenades, fast_throw, shoot_grenades, fovhack;
bool detect_ammocheat, detect_statscheat, detect_spam;
bool get_host, kick_enemy, delete_enemy, kill_enemy, fastround;
int hands_x, hands_y, hands_z; static int grenade_type = 0;
float bhopvalue = 5.0f; float xu = 0; float yu = 0; float speed_value = 5.0f; static int shootgrenade_type = 0;
float noclipSpeed = 20; float fovValue = 60.0f; float thirdfloat = 2.5f;

bool aim, aimbot_visiblecheck, drawaimbotfov;
float aimbotfov = 30.0f;
ImVec4 aimfovcolor = ImVec4(0, 255, 0, 255);
bool autofire, drawautofirefov; 
int autofirefov = 30; float autofire_delta = 0.5f;
ImVec4 autofirefov_clr = ImVec4(255, 60, 255, 255);
bool silentaim, drawsilentfov;
int silent_hitbox = 0; int silentaimfov;
ImVec4 silentaimclr = ImVec4(255,0,0,255);

bool EspEn, EspLine, EspBox, EspGradient, EspName, EspDistance, EspSkeleton, EspHealth, EspMoney, EspChinaHat, EspPlayerCircle, EspWeapon, EspWeaponIcon, EspPing, EspMoney;
ImVec4 box = ImVec4(255,0,0,255);
ImVec4 gradient = ImVec4(255,0,0,255);
ImVec4 line = ImVec4(255,0,0,255);

// HOOKS // HOOKS // HOOKS // HOOKS // HOOKS
Vector3 (*get_position)(void* player);
Vector3 (*get_right)(void* transform);
Vector3 (*WorldToScreenPoint)(void *camera, Vector3 position);
void (*ThrowGrenade)(void* _this, int weaponId, Vector3 position, Vector3 direction, float movementVelocity, int throwType); 
void (*PlantBomb)(void* instance, Vector3 position, float yRotation);
void (*StartDefuse)(void* instance, float defuseDistance, float defuseDuration);
void (*Done)(void* instance, bool defused, double time);
void (*set_position)(void* transform, Vector3 newPosition);
void (*set_localEulerAngles)(void* transform, Vector3 position);
void (*OpenURL)(monoString* url);
short (*get_MagazineCapacity)(void* wpn);
void (*SetHealth)(void* photonplayer, int health);
void (*DestroyPlayerObjects)(void *photonplayer);
bool (*SetMasterClient)(void *photonplayer);
bool (*CloseConnection)(void *photonplayer);      
void (*set_localScale)(void* transform, Vector3 newSize);
void (*Fire)(void* instance, bool playSound);
void *(*get_transform)(void *instance);
bool (*Linecast)(Vector3, Vector3, int);
void *(*get_camera)();
void (*set_TpsView)(void* player);
int (*GetTeam)(void* negr);
int (*GetHealth)(void* negr);
int (*GetArmor)(void* negr);
int (*GetScore)(void* player);
int (*GetKills)(void* player);
int (*GetAssists)(void* player);
int (*GetDeath)(void* player);
int (*GetPing)(void* player);
int (*GetMoney)(void* negr);
bool (*IsLocal)(void* player);
Vector3 (*get_forward)(void*);
void *(*get_bipedmap)(void *nuls);
monoString *(*get_name)(void *player);
float (*get_deltaTime)();
Vector3 (*getAxis)(void*);
bool (*IsFiring)(void*);

// CASTS // CASTS // CASTS // CASTS // CASTS // CASTS 
static void *get_photon(void *player) { 
   return *(void **)((uint64_t) player + oxorany(0x88)); 
}
static void *get_arm(void* player) {  
   return *(void **)((uint64_t) player + oxorany(0x1C));
}
static void *get_armanimation(void *player) { 
   return *(void **)((uint64_t) player + oxorany(0x54)); 
}
void *get_head(void *player) {
   return *(void **)((uint64_t) get_bipedmap(player) + oxorany(0xC)); 
}
void *get_neck(void *player) { 
   return *(void **)((uint64_t) get_bipedmap(player) + oxorany(0x10)); 
}
void *get_hip(void *player) { 
   return *(void **)((uint64_t) get_bipedmap(player) + oxorany(0x3C)); 
}
Vector3 GetPlayerHead(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0xC)));
}
Vector3 GetPlayerNeck(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x10)));
}
Vector3 GetPlayerHip(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x3C)));
}
Vector3 GetPlayerleftLowerArm(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x24)));
}
Vector3 GetPlayerLeftHand(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x28)));
}
Vector3 GetPlayerRightHand(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x38)));
}
Vector3 GetPlayerleftUpperArm(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x20)));
}
Vector3 GetPlayerrightLowerArm(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x34)));
}
Vector3 GetPlayerrightUpperArm(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x30)));
}
Vector3 GetPlayerleftLowerLeg(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x48)));
}
Vector3 GetPlayerleftUpperLeg(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x44)));
}
Vector3 GetPlayerrightLowerLeg(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x54)));
}
Vector3 GetPlayerrightUpperLeg(void *player) {
    return get_position(*(void **) ((uint64_t) get_bipedmap(player) + oxorany(0x50)));
}
bool IsPlayerVisible(void* player) {
    if (get_camera()) {
        Vector3 CameraPos = get_position(get_transform(get_camera()));

        bool CanSeeHead = !Linecast(CameraPos, GetPlayerHead(player), 16384);
        bool CanSeeHip = !Linecast(CameraPos, GetPlayerHip(player), 16384);
        bool CanSeeLeftLowerArm = !Linecast(CameraPos, GetPlayerleftLowerArm(player), 16384);
        bool CanSeeRightLowerArm = !Linecast(CameraPos,GetPlayerrightLowerArm(player), 16384);
        bool CanSeeLeftLowerLeg = !Linecast(CameraPos, GetPlayerleftLowerLeg(player), 16384);
        bool CanSeeRightLowerLeg = !Linecast(CameraPos,GetPlayerrightLowerLeg(player), 16384);

        return CanSeeHead || CanSeeHip || CanSeeLeftLowerArm || CanSeeRightLowerArm || CanSeeLeftLowerLeg || CanSeeRightLowerLeg;
    }
    return false;
}
ImVec2 world2screen_i(Vector3 pos) {
    auto cam = get_camera();
    if (!cam) return {0, 0};
    Vector3 worldPoint = WorldToScreenPoint(cam, pos);

    return {worldPoint.x, glHeight - worldPoint.y};
}
ImVec2 world2screen_c(Vector3 pos, bool &checker) {
    auto cam = get_camera();
    if (!cam) return {0, 0};
    Vector3 worldPoint = WorldToScreenPoint(cam, pos);

    checker = worldPoint.z > 1;
    return ImVec2(worldPoint.x, glHeight - worldPoint.y);
}
std::map<int, std::string> weaptofont = {
        {11, oxorany("A")},
        {12, oxorany("B")},
        {13, oxorany("C")},
        {15, oxorany("G")},
        {16, oxorany("E")},
        {17, oxorany("F")},
        {32, oxorany("M")},
        {34, oxorany("O")},
        {35, oxorany("P")},
        {36, oxorany("N")},
        {37, oxorany("L")},
        {42, oxorany("b")},
        {43, oxorany("U")},
        {44, oxorany("S")},
        {45, oxorany("V")},
        {46, oxorany("T")},
        {47, oxorany("W")},
        {48, oxorany("R")},
        {49, oxorany("Q")},
        {51, oxorany("Y")},
        {52, oxorany("X")},
        {53, oxorany("Z")},
        {62, oxorany("I")},
        {63, oxorany("H")},
        {69, oxorany("I")},
        {70, oxorany("b")},
        {71, oxorany("c")},
        {72, oxorany("d")},
        {73, oxorany("e")},
        {74, oxorany("b")},
        {75, oxorany("f")},
        {77, oxorany("g")},
        {78, oxorany("i")},
        {79, oxorany("h")},
        {81, oxorany("l")},
        {82, oxorany("k")},
        {91, oxorany("p")},
        {92, oxorany("n")},
        {93, oxorany("o")},
        {99, oxorany("p")},
        {100, oxorany("a")}
};
int GetWeaponID(void*a) {
    auto w1 = *(void **) ((uint64_t) a + oxorany(0x48));
    if (w1) {
      auto w2 = *(void **) ((uint64_t) w1 + oxorany(0x50));
      if (w2) {
        auto w3 = *(void **) ((uint64_t) w2 + oxorany(0x54));
        if (w3) {
          auto w4 = *(int *) ((uint64_t) w3 + oxorany(0xC));
          if (w4) return w4;
        }
      }
    }
}
Vector3 NormalizeAngles(Vector3 angles){
    angles.x = Vector3::NormalizeAngle(angles.x);
    angles.y = Vector3::NormalizeAngle(angles.y);
    angles.z = Vector3::NormalizeAngle(angles.z);
    return angles;
}
Vector3 ToEulerRad(Quaternion q1){
    float sqw = q1.w * q1.w;
    float sqx = q1.x * q1.x;
    float sqy = q1.y * q1.y;
    float sqz = q1.z * q1.z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.x * q1.w - q1.y * q1.z;
    Vector3 v;

    if (test>0.4995f*unit) {
        v.y = 2.0f * atan2f (q1.y, q1.x);
        v.x = M_PI / 2.0f;
        v.z = 0;
        return NormalizeAngles(v * Rad2Deg);
    }
    if (test<-0.4995f*unit) {
        v.y = -2.0f * atan2f (q1.y, q1.x);
        v.x = -M_PI / 2.0f;
        v.z = 0;
        return NormalizeAngles(v * Rad2Deg);
    }
    Quaternion q(q1.w, q1.z, q1.x, q1.y);
    v.y = atan2f (2.0f * q.x * q.w + 2.0f * q.y * q.z, 1 - 2.0f * (q.z * q.z + q.w * q.w));
    v.x = asinf (2.0f * (q.x * q.z - q.w * q.y));
    v.z = atan2f (2.0f * q.x * q.y + 2.0f * q.z * q.w, 1 - 2.0f * (q.y * q.y + q.z * q.z));
    return NormalizeAngles(v * Rad2Deg);
}
bool isFov(Vector2 vec1, Vector2 vec2, int radius) {
	int x = vec1.x;
	int y = vec1.y;
	
	int x0 = vec2.x;
	int y0 = vec2.y;
	
	if ((pow(x - x0, 2) + pow(y - y0, 2)) <= pow(radius, 2)) {
		return true;
	} else {
		return false;
	}
}
void clearPlayers() {
    std::vector<void*> pls;
    for (int i = 0; i < players.size(); i++) {
        if (players[i] != NULL&&get_photon(players[i])!=NULL&&GetHealth(get_photon(players[i]))>0&&me&&GetTeam(players[i])!=GetTeam(me)) {
            pls.push_back(players[i]);
        }
    }
    players = pls;
}
int get_3D_Distance(int Self_x, int Self_y, int Self_z, int Object_x, int Object_y, int Object_z)
{
    int x, y, z;
    x = Self_x - Object_x;
    y = Self_y - Object_y;
    z = Self_z - Object_z;
    return (int)(sqrt(x * x + y * y + z * z));
}
bool playerFind(void *pl) {
    if (pl != NULL) {
        for (int i = 0; i < players.size(); i++) {
            if (pl == players[i]) return true;
        }
    }
    return false;
}















// FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS
// FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS
// FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS
// FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS
// FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS
void (*ctor)(...);
void chatmanager(void* i) {
    if (i != nullptr) { chatinstance = i; }
    return ctor(i);
}
void (*old_SendToAll)(void* instance, monoString* message);
void SendToAll(void* instance, monoString* message) {
  old_SendToAll(instance, message);
}
void (*_player)(void* player);
void player(void* player) {
   if (IsLocal(get_photon(player))) {
      me = player;
   }
   
   if (me) {
     if (bhop) {
       void *mov = *(void **) ((uint64_t) player + oxorany(0x50));
       if (mov) {
         void *tp = *(void **) ((uint64_t) mov + oxorany(0x40));
         if (tp) {
           void *jp = *(void **) ((uint64_t) tp + oxorany(0x20));
           if (jp) {
             *(float *) ((uint64_t) jp + oxorany(0x30)) = bhopvalue; 
           }
         }
       }
     }
     if (speed_hack) {
       void *mov = *(void **) ((uint64_t) player + oxorany(0x50));
       if (mov) {
         void *tp = *(void **) ((uint64_t) mov + oxorany(0x40));
         if (tp) {
           *(float *) ((uint64_t) tp + oxorany(0x8)) = speed_value; 
         }
       }
     }    
     if (thirdperson) {
       set_TpsView(player);
     }
 if (spam_chat && chatinstance != nullptr) {
       static float timer;
       ImGuiIO io = ImGui::GetIO();
       timer += io.DeltaTime;
       
       if (timer >= 0.01f) {
          old_SendToAll(chatinstance, il2cpp_string_new(oxorany("t.me/TurboHackMods")));
          timer = 0;
       }
     }
     if (noclip) {
            if (atu && get_camera()) {
                xu = getAxis(atu).x;
                yu = getAxis(atu).y;                  
         
          auto transfer = (get_forward(get_transform(get_camera())) * yu + get_right(get_transform(get_camera())) * xu) * get_deltaTime() * noclipSpeed;
                 
          flypos = flypos + transfer;
          set_position(get_transform(me), flypos);
         }
        }
     if (underground) {
       set_position(get_transform(me), Vector3(0, 30, 0));
     }
     if (insky) {
       set_position(get_transform(me), Vector3(40, 40, 40));
     }
     if (leftarm) {
       set_localScale(get_transform(get_arm(player)), Vector3(-1, 1, 1));
     } else {
       set_localScale(get_transform(get_arm(player)), Vector3(1, 1, 1));
     }
     if (hands_pos) {
       void *arms = get_armanimation(me);
         if (arms) {
           *(Vector3 *)((uint64_t) arms + oxorany(0x94)) = Vector3(hands_x, hands_y, hands_z) / 50;
           *(bool *) ((uint64_t) arms + oxorany(0x44)) = !hands_pos;
         }
     }
     if (antiaim::enable) { 
       void *aim = *(void **) ((uint64_t) me + oxorany(0x44));
       if (aim) {
         void *aimingParameters = *(void **) ((uint64_t) aim + oxorany(0x58));
         if (aimingParameters) {
           void *FPSOffsetStand = *(void **) ((uint64_t) aimingParameters + oxorany(0x8));
           void *FPSOffsetCrouch = *(void **) ((uint64_t) aimingParameters + oxorany(0xC));
           if (FPSOffsetStand && FPSOffsetCrouch) {
	         bool rr;
	         
	         if (antiaim::randomrotation) {
	           Vector3 stand_rotation = *(Vector3 *) ((uint64_t) FPSOffsetStand + oxorany(0x14));
	           Vector3 crouch_rotation = *(Vector3 *) ((uint64_t) FPSOffsetCrouch + oxorany(0x14));
	           
	           if (stand_rotation.y == 360.0f || crouch_rotation.y == 360.0f) {
	             stand_rotation.y = 0.0f;
	             crouch_rotation.y = 0.0f;
	           }
	           
	           stand_rotation.y += antiaim::aaspeed;
	           crouch_rotation.y += antiaim::aaspeed;
	         }
	         
	         if (antiaim::aastatic) {
	           Vector3 stand_rotation = *(Vector3 *) ((uint64_t) FPSOffsetStand + oxorany(0x14));
	           Vector3 crouch_rotation = *(Vector3 *) ((uint64_t) FPSOffsetCrouch + oxorany(0x14));
	           
	           stand_rotation.y == 180.0f;
	           crouch_rotation.y == 180.0f;
	           
	           stand_rotation.z == 120.0f;
	           crouch_rotation.z == 120.0f;
	         }
           }
         
           if (antiaim::aajitter) {
             void* mov = *(void **) ((uint64_t) me + oxorany(0x50));
             if (mov) {
               void* tr = *(void **) ((uint64_t) mov + oxorany(0x4C));
               if (tr) {
                 set_localEulerAngles(tr, Vector3(0, 180, 0));
               }
             }
           }
         }
       }
     }
     
     if (get_host) {
       SetMasterClient(get_photon(me));
       get_host = false;
     }
     if (GetTeam(me) != GetTeam(player)) {
       enemy = player;
     }
   }
   
   if (enemy) {
      if (bighead) {
        set_localScale(get_transform(get_head(enemy)), Vector3(5, 5, 5));
      } else {
        set_localScale(get_transform(get_head(enemy)), Vector3(1,1,1));
      }
      if (silentaim) {
        void *aimedPlayerHead = *(void **) ((uint64_t) get_bipedmap(enemy) + oxorany(0xC));
        void *aimedPlayerNeck = *(void **) ((uint64_t) get_bipedmap(enemy) + oxorany(0x10)); 
        void *aimedPlayerHip = *(void **) ((uint64_t) get_bipedmap(enemy) + oxorany(0x3C));
        if (silent_hitbox == 0) {
          if (aimedPlayerHead) {
            Vector3 target = get_position(aimedPlayerHead) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (aimAngle <= silentaimfov / 700.0f && target != Vector3(0, 0, 0)) {
                aimedplayer = enemy;
            }                    
          }
        } else if (silent_hitbox == 1) {               
          if (aimedPlayerNeck) {
            Vector3 target = get_position(aimedPlayerNeck) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (aimAngle <= silentaimfov / 700.0f && target != Vector3(0, 0, 0)) {
                aimedplayer = enemy;       
            }
          }
        } else if (silent_hitbox == 2) {
          if (aimedPlayerHip) {
            Vector3 target = get_position(aimedPlayerHip) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (aimAngle <= silentaimfov / 700.0f && target != Vector3(0, 0, 0)) {
                aimedplayer = enemy;
            }
          }
        }
      }
      if (aim) {
        void *aiming = *(void **) ((uint64_t) me + oxorany(0x44));
        if (aiming) {
          void *aimingData = *(void **) ((uint64_t) aiming + oxorany(0x5C));
          if (aimingData) {
            PlayerLook = Quaternion::LookRotation(Vector3(get_position(get_head(enemy)).x, get_position(get_head(enemy)).y - 1.400f, get_position(get_head(enemy)).z) - get_position(get_transform(me)), Vector3(0, 1, 0));
              
            Vector3 angle = ToEulerRad(PlayerLook);
            if (angle.x > 275.0f) angle.x -= 360.0f;
            if (angle.x < -275.0f) angle.x += 360.0f;

            Vector3 target_onscreen = WorldToScreenPoint(get_camera(), Vector3(get_position(get_transform(enemy)).x, get_position(get_transform(enemy)).y, get_position(get_transform(enemy)).z));
            bool IsInsideTheFovCircle = isFov(Vector2(target_onscreen.x, target_onscreen.y), Vector2(glWidth / 2, glHeight / 2), aimbotfov);
            
            if (IsInsideTheFovCircle) {    
              if (aimbot_visiblecheck) {
                if (IsPlayerVisible(enemy)) {
                  *(Vector3 *) ((uint64_t) aimingData + oxorany(0x10)) = angle;
                  *(Vector3 *) ((uint64_t) aimingData + oxorany(0x1C)) = angle;
                }
              } else {
                  *(Vector3 *) ((uint64_t) aimingData + oxorany(0x10)) = angle;
                  *(Vector3 *) ((uint64_t) aimingData + oxorany(0x1C)) = angle;
              }
            }
          }
        }
      }
      if (telekill) {
         Vector3 enemy_position = get_position(get_transform(enemy));
         set_position(get_transform(me), Vector3(enemy_position.x, enemy_position.y, enemy_position.z + 1));
      }
      if (masskill) {
         Vector3 my_position = get_position(get_transform(me));
         set_position(get_transform(enemy), Vector3(my_position.x, my_position.y, my_position.z + 1));
      }
   } else {
     enemy = nullptr;
   }
   
   if (GetHealth(get_photon(player)) > 0) {
      if (!playerFind(player)) players.push_back(player);
         clearPlayers();
   }
  _player(player);
}
void* (*old_CastBullet)(Vector3 startPosition, Vector3 direction,  void* parameters);
void* CastBullet(Vector3 startPosition, Vector3 direction,  void* parameters) {
    if (silentaim && aimedplayer) {
      if (GetTeam(aimedplayer) != GetTeam(me)) {
        void *aimedPlayerHead = *(void **) ((uint64_t) get_bipedmap(aimedplayer) + oxorany(0xC));
        void *aimedPlayerNeck = *(void **) ((uint64_t) get_bipedmap(aimedplayer) + oxorany(0x10)); 
        void *aimedPlayerHip = *(void **) ((uint64_t) get_bipedmap(aimedplayer) + oxorany(0x3C));
        if (silent_hitbox == 0) {
          if (aimedPlayerHead) {
            Vector3 target = get_position(aimedPlayerHead) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (aimAngle <= silentaimfov / 700.0f && target != Vector3(0,0,0)) {       
                direction = Vector3::Normalized(get_position(aimedPlayerHead) - startPosition);
            }
          }
        } else if (silent_hitbox == 1) {  
          if (aimedPlayerNeck) {
            Vector3 target = get_position(aimedPlayerNeck) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (aimAngle <= silentaimfov / 700.0f && target != Vector3(0,0,0)) {
                 direction = Vector3::Normalized(get_position(aimedPlayerNeck) - startPosition);
            }
          }
        } else if (silent_hitbox == 2) {
          if (aimedPlayerHip) {
            Vector3 target = get_position(aimedPlayerHip) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (aimAngle <= silentaimfov / 700.0f && target != Vector3(0,0,0)) {
                 direction = Vector3::Normalized(get_position(aimedPlayerHip) - startPosition);
            }
          }
        }
      }
    }
    
    if (shoot_grenades) {
      ThrowGrenade(grenade_instance, 91 + shootgrenade_type, startPosition, direction, 120.0f, 1);
    }
  return old_CastBullet(startPosition, direction, parameters);
}
void *(*old_Invoke)(void* author, monoString* message, bool all);
void *Invoke(void* author, monoString* message, bool all) {
  if ((author != nullptr) && (author != get_photon(me)) && detect_spam) {
    if (strstr(message->toChars(), oxorany("t.me/")) || strstr(message->toChars(), oxorany("t.me")) || strstr(message->toChars(), oxorany(".t.me")) || strstr(message->toChars(), oxorany("https://")) || strstr(message->toChars(), oxorany("http://")) || strstr(message->toChars(), oxorany(".com")) || strstr(message->toChars(), oxorany(".ru")) || strstr(message->toChars(), oxorany(".xyz")) ||strstr(message->toChars(), oxorany("БЕЗ БАНА")) || strstr(message->toChars(), oxorany("ИГРА ГОВНО"))) {
      std::string a = std::string(get_name(author)->toChars()) + oxorany(" got kicked");
      SendToAll(chatinstance, il2cpp_string_new(a.c_str()));      
      CloseConnection(author);
    }
  }
  return old_Invoke(author, message, all);
}
void (*old_SetJoystickPointerPosition)(void* a, Vector3 b);
void SetJoystickPointerPosition(void* a, Vector3 b) {
    atu = a;
    old_SetJoystickPointerPosition(a, b);
}
void (*old_PlayerControllerLateUpdate)(void *up);
void PlayerControllerLateUpdate(void* up) {
    if (thirdperson) {
        set_position(get_transform(get_camera()), get_position(get_transform(get_camera())) - get_forward(get_transform(get_camera())) * thirdfloat);
    }
    old_PlayerControllerLateUpdate(up);
}
short (*old_Ammo)(void *inst);
short Ammo(void *inst) {
    if (inst != NULL && infammo) {
        return 1;
    }
    return old_Ammo(inst);
}
void (*old_set_fieldOfView)(void *instance, float fov);
void set_fieldOfView(void *instance, float fov) {
  if (instance != NULL) {
    if (fovhack) {
      fov = fovValue;
    }
  }
  old_set_fieldOfView(instance, fov);
}
float (*old_get_fieldOfView)(void *instance);
float get_fieldOfView(void *instance) {
  if (instance != NULL) {
    if (fovhack) {
      return fovValue;
    }
  }
  return old_get_fieldOfView(instance);
}
void (*old_GunController_LocalUpdate)(void *i);
void GunController_LocalUpdate(void *i) {
  if (i != NULL) { 
    void *gunparams = *(void **)((uint64_t) i + oxorany(0xE8));
     
    if (norecoil) {   
	  // this instance
	  *(float *) ((uint64_t) i + oxorany(0xC8)) = 0; 
	  *(float *) ((uint64_t) i + oxorany(0xCC)) = 0; 
       
	  // class GunParameters
	  *(float *) ((uint64_t) gunparams + oxorany(0x5C)) = 0; 
	  *(float *) ((uint64_t) gunparams + oxorany(0x70)) = 0; 
	  *(float *) ((uint64_t) gunparams + oxorany(0x74)) = 0; 
	  *(float *) ((uint64_t) gunparams + oxorany(0x78)) = 0; 
	  *(float *) ((uint64_t) gunparams + oxorany(0x7C)) = 0; 
	  *(float *) ((uint64_t) gunparams + oxorany(0x80)) = 0; 
	  *(float *) ((uint64_t) gunparams + oxorany(0x84)) = 0; 
    }
	 
    if (autofire) {
	  if (enemy && get_camera()) {
	    Vector3 enemy_headpos = get_position(get_transform(get_head(enemy)));
	    Vector3 enemy_headpos_onscreen = WorldToScreenPoint(get_camera(), Vector3(enemy_headpos.x, enemy_headpos.y, enemy_headpos.z));
	    bool IsInsideTheFovCircle = isFov(Vector2(enemy_headpos_onscreen.x, enemy_headpos_onscreen.y), Vector2(glWidth / 2, glHeight / 2), autofirefov);
        
        if (IsInsideTheFovCircle && IsPlayerVisible(enemy)) {
          static float timer;
          ImGuiIO io = ImGui::GetIO();
          timer += io.DeltaTime;
          
          if (timer >= autofire_delta) {
            Fire(i, true);
           timer = 0.0f;
          }
        }
      }
    }
	
    if (firerate) {
	  *(float *) ((uint64_t) i + oxorany(0x6C)) = 0.05f; // private float _fireInterval;
    }
	 
    if (wallshot) {
	  *(int *) ((uint64_t) gunparams + oxorany(0x94)) = 90000000; // private float _fireInterval;
	}
  }
  return old_GunController_LocalUpdate(i);
}
void (*old_Simulate)(void* instance, void* bipedMap, Vector3 velocity, void* hitData, bool shooter); // RagdollController
void Simulate(void* instance, void* bipedMap, Vector3 velocity, void* hitData, bool shooter) {
    if (ragdoll) {
       velocity = Vector3(velocity.x, velocity.y + 20, velocity.z);
    }
    old_Simulate(instance, bipedMap, velocity, hitData, shooter);
}
bool (*old_CanSpawnPlayer)(...);
bool CanSpawnPlayer(void* instance) {
    if (instance != nullptr) {
      if (respawnhack) {
         return true;
      }
    }
    return old_CanSpawnPlayer(instance);
}
bool (*old_isGrounded)(void* inst);
bool isGrounded(void* inst) {
    if (inst != NULL && airjump) {
       return true;
    } else {
       return old_isGrounded(inst);
    }
}
bool (*old_CanDefuse)(...);
bool CanDefuse(void* instance, float defuseDistance) {
    if (instance != nullptr && defuseanywhere) {
       return true;
    } else {
       return old_CanDefuse(instance, defuseDistance);
    }
}
void (*old_hit)(void* a, void* b, void* c, int d, int e);
void hit(void* a, void* b, void* c, int d, int e) {
    monoArray<void *> *hits = *(monoArray<void *> **) ((uint64_t) b + 0x2C);
    void *firsthit = hits->getPointer()[0];
    if (dmghack) { 
     *(int *) ((uint64_t) firsthit + oxorany(0x24)) = 200; 
   }
    if (onlyhead) { 
     *(int *) ((uint64_t) firsthit + oxorany(0x2C)) = 0; 
   }
    if (nopenetration) {
     *(bool *) ((uint64_t) firsthit + oxorany(0x30)) = false;
   }

    old_hit(a,b,c,d,e);
}
void (*old_Instantiate)(void* instance, int health, int armor, bool hasHelmet, bool untouchable, float untouchableDuration);
void Instantiate(void* instance, int health, int armor, bool hasHelmet, bool untouchable, float untouchableDuration) {
     if (instance != NULL && godmode) {
        untouchable = true;
        untouchableDuration = 9999.0f;
     }
  return old_Instantiate(instance, health, armor, hasHelmet, untouchable, untouchableDuration);
}
void (*old_GrenadeManager_Update)(...);
void GrenadeManager_Update(void* instance) {
     if (instance != nullptr) {
       grenade_instance = instance;
     }
     
     if (nuke) {
        if (nuke_me && me && instance != nullptr) {
           ThrowGrenade(instance, 91 + grenade_type, Vector3(get_position(get_transform(me)).x, get_position(get_transform(me)).y + 0.15f, get_position(get_transform(me)).z), Vector3(get_position(get_transform(me)).x, get_position(get_transform(me)).y, get_position(get_transform(me)).z), 0.0f, 0);
        }
      
        if (nuke_enemy && enemy && instance != nullptr) {
           ThrowGrenade(instance, 91 + grenade_type, Vector3(get_position(get_transform(enemy)).x, get_position(get_transform(enemy)).y + 0.15f, get_position(get_transform(enemy)).z), Vector3(get_position(get_transform(enemy)).x, get_position(get_transform(enemy)).y, get_position(get_transform(enemy)).z), 0.0f, 0);
        }
     }
   old_GrenadeManager_Update(instance);  
}
void (*old_BombManager_Update)(...);
void BombManager_Update(void* instance) {
    if (instance != nullptr) {
      if (fastdefuse) {
         *(float *) ((uint64_t) instance + oxorany(0x30)) = 0.0f;
      }
      
      if (autowin_ct) {
         defuseanywhere = true;
         PlantBomb(instance, Vector3(get_position(get_transform(me)).x, get_position(get_transform(me)).y, get_position(get_transform(me)).z), 2.0f);
         StartDefuse(instance, 999.9f, 0.1f);
         defuseanywhere = false;
         autowin_ct = false;
      }
      
      if (autowin_tr) {
         PlantBomb(instance, Vector3(get_position(get_transform(enemy)).x, get_position(get_transform(enemy)).y, get_position(get_transform(enemy)).z), 2.0f);
         Done(instance, false, 0.0f);
         autowin_tr = false;
      }
    }
  old_BombManager_Update(instance);
}
void (*old_KnifeController_LocalUpdate)(void *i);
void KnifeController_LocalUpdate(void *i) {
  if (i != NULL) {  
    if (fastknife) {
      *(float *) ((uint64_t) i + oxorany(0x78)) = 0.1f;
    }
  }
  return old_KnifeController_LocalUpdate(i);
}
double (*old_GetTime)(void* room);
double GetTime(void* room) {
  if (fastround) {
    return -10000;
  }
  return old_GetTime(room);
}
void (*old_PlayerAttr)(void* i, monoString* uid, monoString* name,monoArray<unsigned char>* avatar, int badgeId, bool fromLobby, bool bot);
void PlayerAttr(void* i, monoString* uid, monoString* name, monoArray<unsigned char>* avatar, int badgeId, bool fromLobby, bool bot) {
    old_PlayerAttr(i, il2cpp_string_new(oxorany("t.me/TurboHackMods")), name, avatar, badgeId, fromLobby, false);
}
void (*old_DetonateViaServer)(void* i, monoArray<unsigned char>* idk, void* msginfo);
void DetonateViaServer(void* i, monoArray<unsigned char>* idk, void* msginfo) {
  if (anti_grenade && i != nullptr) return;
  old_DetonateViaServer(i, idk, msginfo);
}
void *(*old_GrenadeController_LocalUpdate)(void* i);
void *GrenadeController_LocalUpdate(void* i) {
  if (i != nullptr) {
    void *GrenadeParameters = *(void **) ((uint64_t) i + oxorany(0x74));
    if (GrenadeParameters != nullptr) {
      if (fast_throw) {
        *(float *) ((uint64_t) GrenadeParameters + oxorany(0x40)) = 0.0f;
        *(float *) ((uint64_t) GrenadeParameters + oxorany(0x44)) = 0.0f;
      }
    }
    
    if (infinitegrenades) {
      *(bool *) ((uint64_t) i + oxorany(0x84)) = true;
    }
  }
  return old_GrenadeController_LocalUpdate(i);
}






void InitializeOffsets() {
	do {
		usleep(1);
		} while (!Il2cppLoaded());
		
	// Offset
	
	MemoryPatch::createWithHex(0x12345000, oxorany("1E FF 2F E1")).Modify();
hexPatch.movebef = MemoryPatch::createWithHex(0x12345010, oxorany("1E FF 2F E1"));
hexPatch.infdrop = MemoryPatch::createWithHex(0x12345020, oxorany("1E FF 2F E1"));
hexPatch.fastboom = MemoryPatch::createWithHex(0x12345030, oxorany("01 00 A0 E3 1E FF 2F E1"));
hexPatch.friendly = MemoryPatch::createWithHex(0x12345040, oxorany("01 00 A0 E3 1E FF 2F E1"));
hexPatch.invis = MemoryPatch::createWithHex(0x12345050, oxorany("1E FF 2F E1"));

Tools::Hook(0x12345060, (void *) PlayerAttr, (void **) &old_PlayerAttr);
Tools::Hook(0x12345070, (void *) Simulate, (void **) &old_Simulate);
Tools::Hook(0x12345080, (void *) BombManager_Update, (void **) &old_BombManager_Update);
Tools::Hook(0x12345090, (void *) CastBullet, (void **) &old_CastBullet);
Tools::Hook(0x12345100, (void *) Ammo, (void **) &old_Ammo);
Tools::Hook(0x12345110, (void *) CanSpawnPlayer, (void **) &old_CanSpawnPlayer);
Tools::Hook(0x12345120, (void *) GrenadeController_LocalUpdate, (void **) &old_GrenadeController_LocalUpdate);
Tools::Hook(0x12345130, (void *) isGrounded, (void **) &old_isGrounded);
Tools::Hook(0x12345140, (void *) DetonateViaServer, (void **) &old_DetonateViaServer);
Tools::Hook(0x12345150, (void *) CanDefuse, (void **) &old_CanDefuse);
Tools::Hook(0x12345160, (void *) hit, (void **) &old_hit);
Tools::Hook(0x12345170, (void *) Instantiate, (void **) &old_Instantiate);
Tools::Hook(0x12345180, (void *) GrenadeManager_Update, (void **) &old_GrenadeManager_Update);
Tools::Hook(0x12345190, (void *) chatmanager, (void **) &ctor);
Tools::Hook(0x12345200, (void *) &SendToAll, (void **) &old_SendToAll);
Tools::Hook(0x12345210, (void *) SetJoystickPointerPosition, (void **) &old_SetJoystickPointerPosition);
Tools::Hook(0x12345220, (void *) KnifeController_LocalUpdate, (void **) &old_KnifeController_LocalUpdate);
Tools::Hook(0x12345230, (void *) GetTime, (void **) &old_GetTime);
Tools::Hook(0x12345240, (void *) &GunController_LocalUpdate, (void **) &old_GunController_LocalUpdate);
Tools::Hook(0x12345250, (void*) Invoke, (void**) &old_Invoke);
Tools::Hook(0x12345260, (void *) &player, (void **) &_player);
Tools::Hook(0x12345270, (void *) &PlayerControllerLateUpdate, (void **) &old_PlayerControllerLateUpdate);

Fire = (void (*)(void*, bool)) 0x12345280;
SetMasterClient = (bool (*)(void *)) 0x12345290;
CloseConnection = (bool (*)(void *)) 0x12345300;
DestroyPlayerObjects = (void (*)(void *)) 0x12345310;
SetHealth = (void (*)(void*, int)) 0x12345320;
GetPing = (int (*)(void *)) 0x12345330;
IsFiring = (bool (*)(void*)) 0x12345340;
ThrowGrenade = (void (*)(void *, int, Vector3, Vector3, float, int)) 0x12345350;
PlantBomb = (void (*)(void*, Vector3, float)) 0x12345360;
StartDefuse = (void (*)(void*, float, float)) 0x12345370;
Done = (void (*)(void*, bool, double)) 0x12345380;
getAxis = (Vector3 (*)(void *)) 0x12345390;
get_deltaTime = (float (*)()) 0x12345400;
get_name = (monoString *(*)(void *)) 0x12345410;
get_bipedmap = (void *(*)(void *)) 0x12345420;
get_transform = (void *(*)(void *)) 0x12345430;
get_position = (Vector3 (*)(void *)) 0x12345440;
get_right = (Vector3 (*)(void *)) 0x12345450;
set_position = (void (*)(void*, Vector3)) 0x12345460;
set_localEulerAngles = (void (*)(void*, Vector3)) 0x12345470;
Linecast = (bool (*)(Vector3, Vector3, int)) 0x12345480;
OpenURL = (void (*)(monoString*)) 0x12345490;
get_MagazineCapacity = (short (*)(void*)) 0x12345500;
GetScore = (int (*)(void*)) 0x12345510;
GetKills = (int (*)(void*)) 0x12345520;
GetAssists = (int (*)(void*)) 0x12345530;
GetDeath = (int (*)(void*)) 0x12345540;
get_forward = (Vector3 (*)(void*)) 0x12345550;
set_localScale = (void (*)(void*, Vector3)) 0x12345560;
get_camera = (void *(*)()) 0x12345570;
WorldToScreenPoint = (Vector3 (*)(void *, Vector3)) 0x12345580;
set_TpsView = (void (*)(void*)) 0x12345590;
GetTeam = (int (*)(void *)) 0x12345600;
GetHealth = (int (*)(void *)) 0x12345610;
GetArmor = (int (*)(void *)) 0x12345620;
GetMoney = (int (*)(void *)) 0x12345630;
IsLocal = (bool (*)(void *)) 0x12345640;
	
}
