void ColorPicker(const char* name, ImVec4 &color, bool prd = false, bool* rainbow = nullptr, bool* pulse = nullptr, bool* dark = nullptr) {
    ImGuiColorEditFlags misc_flags = ImGuiColorEditFlags_AlphaPreview;
    static ImVec4 backup_color;
	auto s = ImGui::GetWindowDrawList();
	
    bool open_popup = ImGui::ColorButton((std::string(name) + std::string(("##3b"))).c_str(), color, misc_flags);
	
    if (open_popup) {
        ImGui::OpenPopup(name);
        backup_color = color;
    }
	
    if (ImGui::BeginPopup(name)) {
       // ImGui::Text(("%s"), std::string(name).c_str());
        ImGui::Separator();
        ImGui::ColorPicker4(("##picker"), (float *) &color,misc_flags |ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar |ImGuiColorEditFlags_NoOptions );
        if (prd) {
            if (rainbow) ImGui::Checkbox(("Rainbow"), rainbow);
            if (pulse) ImGui::Checkbox(("Pulse"), pulse);
            if (dark) ImGui::Checkbox(("Dark"), dark);
        }
        ImGui::EndPopup();
    }
 }/*

void ColorPicker(const char* Name, ImVec4 &Color) {
    ImGuiColorEditFlags MiscFlags = ImGuiColorEditFlags_AlphaPreview;
    static ImVec4 BackupColor;

    bool OpenPopup = ImGui::ColorButton((std::string(Name) + "##3b").c_str(), Color, MiscFlags);
	
	if (OpenPopup) {
        ImGui::OpenPopup(Name);
        BackupColor = Color;
    }
	
    if (ImGui::BeginPopup(Name))  {
		
        ImGui::ColorPicker4("##Picker", (float*)&Color, MiscFlags | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview);
        ImGui::SameLine();

        ImGui::BeginGroup();
        ImGui::Text("Current");
		SameLine();
        ImGui::ColorButton("##TEST666", Color, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf, ImVec2(35, 15));
        ImGui::Text("Original");
		SameLine();
        if (ImGui::ColorButton("##TEST777", BackupColor, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf, ImVec2(35, 15)))
            Color = BackupColor;
        ImGui::EndGroup();
        ImGui::EndPopup();
    }
}*/
