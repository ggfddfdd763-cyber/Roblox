#include "Includes/Includes.h"
#include "MenuFonts/ImFonts.h"
#include "colors.h"
#include "dimensions.h"

namespace MainMenu {
	
	#include "other.h"
	
	float menu_alpha = 0.0f;
	
	void update_menu() {
		if (open_menu) {
			if (menu_alpha < 1.0f) {
				menu_alpha += 0.01f;
			}
		} else {
       	 	if (menu_alpha > 0.0f) {
            	menu_alpha -= 0.01f;
        	}
    	}
	}
	
	void DrawMenu() {
		static int Page = 1;

		#include "garbage.h"
		bool babulya = false;
		if (babulya) {
			Banana();
		}
		
		if (!open_menu) return;
		
		SetNextWindowPos(ImVec2(200, 50), ImGuiCond_FirstUseEver);
		SetNextWindowSize(ImVec2(800, 620), ImGuiCond_FirstUseEver);
		Begin("##", NULL, 3);
	
		SetCursorPos(ImVec2(40, 30));
	    TextGradient("Elysterial", ImVec4(1.0f, 1.0f, 1.0f, 1.0f), ImVec4(menu_accent));
		SetCursorPos(ImVec2(30, 45));
		TextColored(ImColor(100, 100, 100), "__________");
		SetCursorPosY(85);
		if (MainMenu::RenderButton("Combat", Page == 1, {140, 40})) Page = 1;
		if (MainMenu::RenderButton("Visuals", Page == 2, {140, 40})) Page = 2;
		if (MainMenu::RenderButton("Player", Page == 3, {140, 40})) Page = 3;
		if (MainMenu::RenderButton("Skin changer", Page == 4, {140, 40})) Page = 4;
		if (MainMenu::RenderButton("Settings", Page == 5, {140, 40})) Page = 5;
		if (MainMenu::RenderButton("Configs", Page == 6, {140, 40})) Page = 6;
		
		ImVec2 ChildPosition1 = ImVec2(157, 5);
		ImVec2 ChildPosition2 = ImVec2(472, 5);
		ImVec2 ChildSize = ImVec2(325, -0);
		ImVec2 ChildSizeFull = ImVec2(-0, -0);
		// все что есть CheckBox if (TreeNode("ESP Line")) {
		if (Page == 1) {
			SetCursorPos(ChildPosition1);
			BeginChild("##Page 1", ChildSize, true);

			EndChild();
		}
		
		if (Page == 2) {
			SetCursorPos(ChildPosition1);
			BeginChild("##Page 2", ChildSize, true);;
			TextColored(ImVec4(menu_accent), "ESP");
		    Separator();
			Spacing();
		
				}
				TreePop();
		    }
			
		        if (ImGui::CollapsingHeader(oxorany("ESP"))) {
	ImGui::Checkbox(oxorany("Box"), &EspBox);
    ImGui::SameLine();
    TurboMods::AddColorPicker(oxorany("Box Color"), box);
    ImGui::Checkbox(oxorany("Gradient"), &EspGradient);
    ImGui::SameLine();
    TurboMods::AddColorPicker(oxorany("Gradient Color"), gradient);
    ImGui::Checkbox(oxorany("Line"), &EspLine);
    ImGui::SameLine();
    TurboMods::AddColorPicker(oxorany("Line Color"), line);
    ImGui::Checkbox(oxorany("Name"), &EspName);
    ImGui::Checkbox(oxorany("Distance"), &EspDistance);
	ImGui::Checkbox(oxorany("Health Bar"), &EspHealth);
	ImGui::Checkbox(oxorany("Money"), &EspMoney);
	ImGui::Checkbox(oxorany("Ping"),&EspPing);
    ImGui::Checkbox(oxorany("Weapon"),&EspWeapon);
    ImGui::Checkbox(oxorany("Weapon Icon"),&EspWeaponIcon);
    ImGui::Checkbox(oxorany("Skeleton"),&EspSkeleton);
    ImGui::Checkbox(oxorany("China Hat"),&EspChinaHat);
    ImGui::Checkbox(oxorany("Player Circle"), &EspPlayerCircle);
    
              if (ImGui::CollapsingHeader(("Chams"))) {
ImGui::Checkbox(oxorany("Textures fix"), &texFix);
                        ImGui::Checkbox(oxorany("Transparent mode"), &opacityChams);
                        ImGui::Checkbox(oxorany("Textured"), &texturedChams);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("Visible"), *(ImVec4 *) &visibleTexturedChamsColor, true, &visibleTexturedChamsRainbow, &visibleTexturedChamsPulse);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("Invisible"), *(ImVec4 *) &invisibleTexturedChamsColor, true, &invisibleTexturedChamsRainbow, &invisibleTexturedChamsPulse);
                        ImGui::Checkbox(oxorany("Wireframe"), &wireframeChams);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("WF Color"), *(ImVec4 *) &wireframeChamsColor, true, &wireframeChamsRainbow, &wireframeChamsPulse);
                        if (wireframeChams) {
                        ImGui::Checkbox(oxorany("Wallhack"), &wireframeWallhackChams);
                        ImGui::SliderFloat(oxorany("Width"), &wireframeWidthChams, 1, 5, ("%.1f"));
                        }
                        ImGui::Checkbox(oxorany("Shading"), &shadingChams);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("SH Color"), *(ImVec4 *) &shadingChamsColor);
                        if (shadingChams) {
                        ImGui::Checkbox(oxorany("Wallhack"), &shadingWallhackChams);
                        }
                        ImGui::Checkbox(oxorany("Outline"), &outlineChams);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("OU Color"), *(ImVec4 *) &outlineChamsColor, true, &outlineChamsRainbow, &outlineChamsPulse);
                        if (outlineChams) {
                        ImGui::Checkbox(oxorany("Wallhack"), &outlineWallhackChams);
                        ImGui::SliderFloat(oxorany("Width"), &outlineWidthChams, 1, 5, ("%.1f"));
                        }
                        ImGui::Checkbox(oxorany("Glow"), &glowChams);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("GL Color"), *(ImVec4 *) &glowChamsColor, true, &glowChamsRainbow, &glowChamsPulse);
						ImGui::Separator();
						ImGui::Text(oxorany("Other"));
                        /*ImGui::Checkbox(oxorany("Custom crosshair"), &svaston);
                        ImGui::SliderFloat(oxorany("Crosshair size"), &swscale, 0.f, 50.f, "%.3f", 1.0f);*/
                        ImGui::Checkbox(oxorany("World color"), &nightmode);
                        ImGui::SameLine();
                        TurboMods::AddColorPicker(oxorany("Color"), *(ImVec4 *) &worldChamsColor, true, &worldChamsRainbow);
          }
	
			EndChild();
			SameLine(0, 2);
			SetCursorPos(ChildPosition2);
			BeginChild("##Page 2.1", ChildSize, true);
			TextColored(ImVec4(menu_accent), "Misc");
		    Separator();
			Spacing();
	
		    }
			EndChild();
		}
		
		if (Page == 3) {
			SetCursorPos(ChildPosition1);
			BeginChild("##Page 3", ChildSize, true);
			TextColored(ImVec4(menu_accent), "Player");
		    Separator();
			Spacing();
			/*Toggle("Anti kick", &noKick);
			if (noKick) {
				Text("Notice - disable after mathc!");
			}
			*/
	    ImGui::Text(oxorany("Silent Aim"));
          ImGui::Checkbox(oxorany("Enable"), &silentaim);	
          if (silentaim) {
          ImGui::Checkbox(oxorany("Draw Silent Fov"), &drawsilentfov);
          ImGui::SameLine();
          TurboMods::AddColorPicker(oxorany("Silent Aim FOV Color"), silentaimclr);  
          ImGui::SliderInt(oxorany("Silent Aim Fov"), &silentaimfov, 0, 700);
          ImGui::SliderInt(oxorany("Bone:"), &silent_hitbox, 0, 2);
          ImGui::SameLine();
          if (silent_hitbox == 0) { ImGui::Text(oxorany("Head")); }
          if (silent_hitbox == 1) { ImGui::Text(oxorany("Neck")); }
          if (silent_hitbox == 2) { ImGui::Text(oxorany("Hip")); }
          }
          
          ImGui::Text(oxorany("Aimbot"));
          ImGui::Checkbox(oxorany("Enable"), &aim);	
          if (aim) {
          ImGui::Checkbox(oxorany("Draw Aimbot Fov"), &drawaimbotfov);
          ImGui::SameLine();
          TurboMods::AddColorPicker(oxorany("Aimbot FOV Color"), aimfovcolor);  
          ImGui::SliderFloat(oxorany("Aim Fov"), &aimbotfov, 30, 700);
          ImGui::Checkbox(oxorany("Aimbot Visible Check"), &aimbot_visiblecheck);
          }
          
          
          ImGui::Text(oxorany("Auto Fire"));
          ImGui::Checkbox(oxorany("Enable"), &autofire);	
          if (autofire) {
          ImGui::Checkbox(oxorany("Draw Autofire Fov"), &drawautofirefov);
          ImGui::SameLine();
          TurboMods::AddColorPicker(oxorany("Autofire FOV Color"), autofirefov_clr);  
          ImGui::SliderInt(oxorany("Autofire Fov"), &autofirefov, 30, 300);
          ImGui::SliderFloat(oxorany("Autofire Delta"), &autofire_delta, 0.0f, 1.0f);
          }
        } else if (page == 2) {
            ImGui::Checkbox(oxorany("AutoFixScrene"), &AutoFixScrene);
            ImGui::Checkbox(oxorany("Spam Chat"), &spam_chat);
            ImGui::Separator();
			}
			ImGui::Checkbox(oxorany("No Recoil"), &norecoil);
            ImGui::Checkbox(oxorany("Infinity ammo"), &infammo);
            ImGui::Checkbox(oxorany("Wallshot"), &wallshot);
            ImGui::Checkbox(oxorany("Fire Rate"), &firerate);
            ImGui::Checkbox(oxorany("One Hit Kill"), &dmghack);
            ImGui::Checkbox(oxorany("Fast Knife"), &fastknife);
            ImGui::Checkbox(oxorany("Infinite Grenades"), &infinitegrenades);
            ImGui::Checkbox(oxorany("Fast Grenade Throw"), &fast_throw);
            ImGui::Checkbox(oxorany("Big Head (enemy)"), &bighead);
            ImGui::Checkbox(oxorany("Headshots Only"), &onlyhead);
            ImGui::Checkbox(oxorany("Air Jump"), &airjump);
            ImGui::Checkbox(oxorany("Third Person"), &thirdperson);
            if (thirdperson) {
            ImGui::SliderFloat(oxorany("Third Person Distance"), &thirdfloat, 0.0f, 5.0f);
            }
            ImGui::Checkbox(oxorany("Left Arm"), &leftarm);
            ImGui::Checkbox(oxorany("Ragdoll"), &ragdoll);
            ImGui::Checkbox(oxorany("Antiaim"), &antiaim::enable);
            if (antiaim::enable) {
            ImGui::Checkbox(oxorany("Static"), &antiaim::aastatic);
            ImGui::Checkbox(oxorany("Jitter"), &antiaim::aajitter);
            ImGui::Checkbox(oxorany("Random Rotation"), &antiaim::randomrotation);
            if (!antiaim::aastatic) {
            ImGui::SliderFloat(oxorany("Speed"), &antiaim::aaspeed, 0.0f, 50.0f);
            }
            }
            ImGui::Checkbox(oxorany("Move Before Timer"), &movebeforetimer);
            if (movebeforetimer) {
              hexPatch.movebef.Modify();
            } else {
               hexPatch.movebef.Restore();
            }
            ImGui::Checkbox(oxorany("Infinity Drops"), &infinitydrops);
            if (infinitydrops) {
               hexPatch.infdrop.Modify();
            } else {
               hexPatch.infdrop.Restore();
            }
            ImGui::Checkbox(oxorany("Fast Bomb"), &fastbomb);
            if (fastbomb) {
              hexPatch.fastboom.Modify();
            } else {
              hexPatch.fastboom.Restore();
            }
            ImGui::Checkbox(oxorany("Friendly Fire"), &friendlyfire);
            if (friendlyfire) {
              hexPatch.friendly.Modify();
            } else {
              hexPatch.friendly.Restore();
            }
            ImGui::Checkbox(oxorany("Invisible God Mode"), &invisible);
            if (invisible) {
               hexPatch.invis.Modify();
            } else {
               hexPatch.invis.Restore();
            }
            ImGui::Checkbox(oxorany("Noclip"), &noclip);
            if (noclip) {
            ImGui::SliderFloat(oxorany("Noclip speed"), &noclipSpeed, 1, 20);
            }
            ImGui::Checkbox(oxorany("God Mode"), &godmode);
            ImGui::Checkbox(oxorany("Respawn Hack"), &respawnhack);
            ImGui::Checkbox(oxorany("Defuse Anywhere"), &defuseanywhere);
            ImGui::Checkbox(oxorany("Shoot Grenades"), &shoot_grenades);
            if (shoot_grenades) {
            ImGui::Combo(oxorany("Grenade Type ##shoot"), &shootgrenade_type, grenades, IM_ARRAYSIZE(grenades));
            }
            ImGui::Checkbox(oxorany("Nuke"), &nuke);
            if (nuke) {
            ImGui::Combo(oxorany("Grenade Type"), &grenade_type, grenades, IM_ARRAYSIZE(grenades));
            ImGui::Checkbox(oxorany("Nuke (ME)"), &nuke_me);
            ImGui::Checkbox(oxorany("Nuke (ENEMY)"), &nuke_enemy);
            }
            ImGui::Checkbox(oxorany("FOV Hack"), &fovhack);
            if (fovhack) {
            ImGui::SliderFloat(oxorany("FOV Value"), &fovValue, 60.0f, 180.0f);
            }
            ImGui::Checkbox(oxorany("Anti Grenades"), &anti_grenade);
            ImGui::Checkbox(oxorany("Bunnyhop"), &bhop);
            if (bhop) { 
            ImGui::SliderFloat(oxorany("Bhop Value"), &bhopvalue, 0.0f, 30.0f); 
            }
            ImGui::Checkbox(oxorany("Speed Hack"), &speed_hack);
            if (speed_hack) { 
            ImGui::SliderFloat(oxorany("Speed Value"), &speed_value, 0.0f, 30.0f); 
            }
            ImGui::Checkbox(oxorany("Custom Hands Position"), &hands_pos);
            if (hands_pos) {
            ImGui::SliderInt(oxorany("Hands X"), &hands_x, -50, 50);
            ImGui::SliderInt(oxorany("Hands Y"), &hands_y, -50, 50);
            ImGui::SliderInt(oxorany("Hands Z"), &hands_z, -50, 50);
            }
            ImGui::Checkbox(oxorany("Fast Defuse"), &fastdefuse);
            ImGui::Checkbox(oxorany("Auto Win (CT)"), &autowin_ct);
            ImGui::Checkbox(oxorany("Auto Win (TR)"), &autowin_tr);
            ImGui::Checkbox(oxorany("Telekill"), &telekill);
            ImGui::Checkbox(oxorany("Masskill"), &masskill);
            ImGui::Checkbox(oxorany("Teleport Underground"), &underground);
            ImGui::Checkbox(oxorany("Teleport In The Sky"), &insky);
            ImGui::Checkbox(oxorany("No Penetration"), &nopenetration);

            ImGui::Text(oxorany("Admin (host needed)"));
            ImGui::Checkbox(oxorany("Get Host"), &get_host);
            ImGui::Checkbox(oxorany("Kick Enemy"), &kick_enemy);
            ImGui::Checkbox(oxorany("Delete Enemy"), &delete_enemy);
            ImGui::Checkbox(oxorany("Kill Enemy"), &kill_enemy);
            ImGui::Checkbox(oxorany("Fast Round"), &fastround);
            
            ImGui::Text(oxorany("Detects (Anticheat)"));
            ImGui::Checkbox(oxorany("Detect Spam"), &detect_spam);
            ImGui::Checkbox(oxorany("Detect Ammo Cheat"), &detect_ammocheat);
            if (detect_ammocheat && get_photon(enemy)) {
              void *weaponry = *(void **) ((uint64_t) enemy + oxorany(0x48));
              if (weaponry != nullptr) {
                void *weapon = *(void **) ((uint64_t) weaponry + oxorany(0x50));
                if (weapon != nullptr) {
                  void *wpnparams = *(void **) ((uint64_t) weapon + oxorany(0x54));
                  if (wpnparams != nullptr) {
                    int wpnid = *(int *) ((uint64_t) wpnparams + oxorany(0xC));
                    if (wpnid >= 11 && wpnid <= 65) {
	                  if (get_MagazineCapacity(weapon) > 50) {
	                    std::string cheater_name = get_name(get_photon(enemy))->get_string();
	                    std::string kk = oxorany("Kicked ") + cheater_name + oxorany(" for Infinity Ammo");
	                    old_SendToAll(chatinstance, il2cpp_string_new(kk.c_str()));
	                    
	                    SetMasterClient(get_photon(me));
	                    CloseConnection(get_photon(enemy));
	                  }
	                }
	              }    
	            }
	          }
	        }
	       
	        ImGui::Checkbox(oxorany("Detect enemy Statistics Cheat"), &detect_statscheat);
	        if (detect_statscheat && get_photon(enemy)) {
	          if (GetScore(get_photon(enemy)) > 80 || GetKills(get_photon(enemy)) > 50 || GetAssists(get_photon(enemy)) > 50 || GetDeath(get_photon(enemy)) > 50) {
	            std::string cheater_name = get_name(get_photon(enemy))->toChars();
	            std::string kk = oxorany("Kicked ") + cheater_name + oxorany(" for Modifying the Scoreboard");     
	            old_SendToAll(chatinstance, il2cpp_string_new(kk.c_str()));
	            
	            SetMasterClient(get_photon(me));
	            CloseConnection(get_photon(enemy));
	          }
	        }
	        
        } // end of the pages // end of page number 3
      } ImGui::EndChild();
    }	
    ImGui::End();
  }
		}
		
		if (Page == 5) {
			time_t now = time(0);
			tm* ltm = localtime(&now);
			char t_time[80]; char t_data[80];
			strftime(t_time, 80, "%d.%m.%Y", ltm);
			strftime(t_data, 80, "%H:%M:%S", ltm);
			
			SetCursorPos(ChildPosition1);
			BeginChild("##Page 5", ChildSizeFull, true);
			TextColored(ImVec4(menu_accent), "Settings");
		    Separator();
			Spacing();
			TextColored(ImColor(200, 200, 200), "Information");
			Text("Modder by Turbo && TG t.me/TurboScriptss ");
			SameLine(0, 2);
			Text("%s", t_data);
			SameLine(0, 2);
			Text(" | ");
			SameLine();
			Text("%s", t_time);
			Text("Version - 2.0| Patch 1 [beta test]");
			Spacing();
			TextColored(ImColor(200, 200, 200), "Menu");
			Text("Accent color");
			SameLine(570);
			ColorPicker("##Menu accent color", *(ImVec4*) &menu_accent);
			Text("Theme");
			if (Button("change theme", ImVec2(210, 40))) chth = !chth;
			Spacing();
			TextColored(ImColor(200, 200, 200), "Watermark");
			Checkbox("Enable / Disable", &Watermark_Bool);
			SameLine(570);
			ColorPicker("##Watermark accent color", *(ImVec4*)&watermark_accent);
			Spacing();
			EndChild();
		}
		
		if (Page == 6) {
			SetCursorPos(ChildPosition1);
			BeginChild("##Page 6", ChildSizeFull, true);
			TextColored(ImVec4(menu_accent), "Configs");
		    Separator();
			Spacing();
			static int selectedItem;
			std::vector<std::string> itemsVec = {"Config 1.json", "Config 2.json", "Config 3.json", "Config 4.json", "Config 5.json"};
			std::vector<const char*> items;
			items.reserve(itemsVec.size());
			for (const auto& item : itemsVec) {
				items.push_back(item.c_str());
			}
			Text("Select config file:");
			ImGui::ListBox("##Configs", &selectedItem, items.data(), static_cast<int>(items.size()));
			if (Button("   Save config   ")) {
				SaveConfig(selectedItem+1);
				Toast("Config successfully saved", 1);
			}
			SameLine(0, 5);
			if (Button("   Load config   ")) {
				LoadConfig(selectedItem+1);
				Toast("Config successfully loaded", 1);
			}
			EndChild();
		}
		End();
	}
}
