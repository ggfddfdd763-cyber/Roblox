void Watermark() {
	SetNextWindowPos(ImVec2(10,  10), ImGuiCond_Always);
	SetNextWindowSize(ImVec2(325,  40), ImGuiCond_Always);
	
	if (!ImGui::Begin("##watermark", NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavInputs | ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoDecoration)) {
		ImGui::End();
        return;
        }
	
	ImGuiIO &io = GetIO();
	time_t now = time(0);
	tm* ltm = localtime(&now);
	char buffer[80];
	strftime(buffer, 80, "%H:%M", ltm);
	std::string datatime = ("%s", buffer);
    
	int fps_counter = io.Framerate;
	std::string fpscounter = std::to_string(fps_counter);
	
	TextColored(ImColor(watermark_accent), " I ");
	SameLine();
	Text("elysterial");
	SameLine();
	TextColored(ImColor(watermark_accent), " · ");
	SameLine();
	Text(datatime.c_str());
	SameLine();
	TextColored(ImColor(watermark_accent), " · ");
	SameLine();
	Text("fps: ");
	SameLine();
	Text(fpscounter.c_str());
	SameLine();
	TextColored(ImColor(watermark_accent), " I ");
   }
   
void Banana() {
	SetNextWindowSize(ImVec2(300,  150), ImGuiCond_FirstUseEver);
	
	if (!ImGui::Begin("##banana", NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavInputs | ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoDecoration)) {
		ImGui::End();
        return;
        }
	
	Text("Customization yaw");
	Separator();
	SliderFloat("Real yaw", &SpinYaw, 0, 360);
	SliderFloat("Fake yaw", &SpinYaw1, 0, 360);
}

void AK() {
    SetNextWindowPos(ImVec2(260,  130), ImGuiCond_Once);
    SetNextWindowSize(ImVec2(100,  100), ImGuiCond_Once);
    if (!ImGui::Begin("##key222", NULL, 3)) {
        ImGui::End();
        return;
        }
        
    ImVec2 Position$$1, Position$$2;
    ImDrawList* Draw$$List;
    const auto& Get$$Window$$Pos = ImGui::GetWindowPos();
    const auto& Get$$Window$$Draw$$List = ImGui::GetWindowDrawList();
    const auto& Get$$Background$$Draw$$List = ImGui::GetBackgroundDrawList();
    const auto& Get$$$Foreground$$$DrawList = ImGui::GetForegroundDrawList();
    
    Position$$1 = ImVec2(2, 4);
    Position$$1.x += Get$$Window$$Pos.x;
    Position$$1.y += Get$$Window$$Pos.y;
    
    Position$$2 = ImVec2(120, 10);
    Position$$2.x += Get$$Window$$Pos.x;
    Position$$2.y += Get$$Window$$Pos.y;
    
    Draw$$List = Get$$Window$$Draw$$List;
    ImGui::SetCursorPos(ImVec2(15.000f, 15.000f));
    
    bool akk_keybind;
    
    if (Button("AK", ImVec2(75, 75))) {
        akk_keybind = !akk_keybind;
    }
    
    if (akk_keybind) {
        noKick = true;
        Draw$$List->AddRectFilled(Position$$1, Position$$2, ImColor(menu_accent));
    } else {
        noKick = false;
        Draw$$List->AddRectFilled(Position$$1, Position$$2, ImColor(0,0,0,0));
   }
   }
   
void TH() {
    SetNextWindowPos(ImVec2(370,  130), ImGuiCond_Once);
    SetNextWindowSize(ImVec2(100,  100), ImGuiCond_Once);
    if (!ImGui::Begin("##key22", NULL, 3)) {
        ImGui::End();
        return;
        }
        
    ImVec2 Position$$1, Position$$2;
    ImDrawList* Draw$$List;
    const auto& Get$$Window$$Pos = ImGui::GetWindowPos();
    const auto& Get$$Window$$Draw$$List = ImGui::GetWindowDrawList();
    const auto& Get$$Background$$Draw$$List = ImGui::GetBackgroundDrawList();
    const auto& Get$$$Foreground$$$DrawList = ImGui::GetForegroundDrawList();
    
    Position$$1 = ImVec2(2, 4);
    Position$$1.x += Get$$Window$$Pos.x;
    Position$$1.y += Get$$Window$$Pos.y;
    
    Position$$2 = ImVec2(120, 10);
    Position$$2.x += Get$$Window$$Pos.x;
    Position$$2.y += Get$$Window$$Pos.y;
    
    Draw$$List = Get$$Window$$Draw$$List;
    ImGui::SetCursorPos(ImVec2(15.000f, 15.000f));
    
    bool th_keybind;
    
    if (Button("TH", ImVec2(75, 75))) {
        th_keybind = !th_keybind;
    }
    
    if (th_keybind) {
        ThirdPerson = true;
        Draw$$List->AddRectFilled(Position$$1, Position$$2, ImColor(menu_accent));
    } else {
        ThirdPerson = false;
        Draw$$List->AddRectFilled(Position$$1, Position$$2, ImColor(0,0,0,0));
   }
   }

void FD() {
    SetNextWindowPos(ImVec2(150,  130), ImGuiCond_Once);
    SetNextWindowSize(ImVec2(100,  100), ImGuiCond_Once);
    if (!ImGui::Begin("##key1", NULL, 3)) {
        ImGui::End();
        return;
        }
        
    ImVec2 Position$$1, Position$$2;
    ImDrawList* Draw$$List;
    const auto& Get$$Window$$Pos = ImGui::GetWindowPos();
    const auto& Get$$Window$$Draw$$List = ImGui::GetWindowDrawList();
    const auto& Get$$Background$$Draw$$List = ImGui::GetBackgroundDrawList();
    const auto& Get$$$Foreground$$$DrawList = ImGui::GetForegroundDrawList();
    
    Position$$1 = ImVec2(2, 4);
    Position$$1.x += Get$$Window$$Pos.x;
    Position$$1.y += Get$$Window$$Pos.y;
    
    Position$$2 = ImVec2(120, 10);
    Position$$2.x += Get$$Window$$Pos.x;
    Position$$2.y += Get$$Window$$Pos.y;
    
    Draw$$List = Get$$Window$$Draw$$List;
    ImGui::SetCursorPos(ImVec2(15.000f, 15.000f));
    
    bool fakeduck_keybind  = false;
    
    if (Button("FD", ImVec2(75, 75))) {
        fakeduck_keybind;
    }
    
    if (fakeduck_keybind) {
        FakeDuck = true;
        Draw$$List->AddRectFilled(Position$$1, Position$$2, ImColor(menu_accent));
    } else {
        FakeDuck = false;
        Draw$$List->AddRectFilled(Position$$1, Position$$2, ImColor(0,0,0,0));
   }
   }


void NightMode() {
	GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), ImVec2(Screen$$width(), Screen$$height()), GetColorU32(ImVec4(0, 0, 0, nightvalue)));
}

bool RenderButton(const char* label, const bool selected, const ImVec2& size_arg)
    {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        if (window->SkipItems)
            return false;

        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

        ImVec2 pos = window->DC.CursorPos;
        ImVec2 size = ImGui::CalcItemSize(size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);
        const ImRect bb(pos, { pos.x + size.x , pos.y + size.y });

        ImGui::ItemSize(size, style.FramePadding.y);
        if (!ImGui::ItemAdd(bb, id))
            return false;

        bool hovered, held;
        bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, NULL);
        
        float deltatime = 1.5f * ImGui::GetIO().DeltaTime;
        static std::map<ImGuiID, float> hover_animation;
        auto it_hover = hover_animation.find(id);
        
        if (it_hover == hover_animation.end())
        {
        hover_animation.insert({ id, 0.f });
        it_hover = hover_animation.find(id);
        }

        it_hover->second = std::clamp(it_hover->second + (2.15f * ImGui::GetIO().DeltaTime *   (hovered ? 1.f : -1.f)), 0.0f, 0.0f);
        it_hover->second *= ImGui::GetStyle().Alpha;

        static std::map<ImGuiID, float> filled_animation;
        auto it_filled = filled_animation.find(id);

        if (it_filled == filled_animation.end())
        {
        filled_animation.insert({ id, 0.f });
        it_filled = filled_animation.find(id);
        }

        it_filled->second = std::clamp(it_filled->second + (2.15f * ImGui::GetIO().DeltaTime * (selected ? 1.f : -1.5f)), it_hover->second, 1.f);
        it_filled->second *= ImGui::GetStyle().Alpha;

        if (selected) {
            window->DrawList->AddRectFilled(bb.Min, bb.Max, ImColor(menu_accent), 4.f);
        } else window->DrawList->AddRectFilled(bb.Min, bb.Max,ImColor(0,0,0,int(0 * ImGui::GetStyle().Alpha)),4.f);		

	    if (selected)
		     window->DrawList->AddText({bb.Min.x + size_arg.x / 2 - ImGui::CalcTextSize(label).x / 2, bb.Min.y + size_arg.y / 2 - ImGui::CalcTextSize(label).y / 2}, ImColor(255,255,255, int(255 * it_filled->second)), label);
        else window->DrawList->AddText({bb.Min.x + size_arg.x / 2 - ImGui::CalcTextSize(label).x / 2, bb.Min.y + size_arg.y / 2 - ImGui::CalcTextSize(label).y / 2}, ImColor(190,190,190, int(255 * ImGui::GetStyle().Alpha)), label);
        return pressed;
    }
