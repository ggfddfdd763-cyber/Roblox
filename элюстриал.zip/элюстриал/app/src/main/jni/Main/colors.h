//ImColor menu_accent = ImColor(128, 134, 150);
int col1 = 128;
int col2 = 134;
int col3 = 150;
ImVec4 menu_accent = ImVec4(128 / 255.f, 134 / 255.f, 150 / 255.f, 255 / 255.f);
//ImColor frame = (menu_accent);
ImColor watermark_accent = ImColor(128, 134, 150);
