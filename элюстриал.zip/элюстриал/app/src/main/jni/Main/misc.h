ImVec2 P1, P2;
ImDrawList* pDrawList;
const auto& CurrentWindowPos = ImGui::GetWindowPos();
const auto& pWindowDrawList = ImGui::GetWindowDrawList();
const auto& pBackgroundDrawList = ImGui::GetBackgroundDrawList();
const auto& pForegroundDrawList = ImGui::GetForegroundDrawList();

P1 = ImVec2(1.000f, 4.000f);
P1.x += CurrentWindowPos.x;
P1.y += CurrentWindowPos.y;

P2 = ImVec2(840.000f, 10.000f);
P2.x += CurrentWindowPos.x;
P2.y += CurrentWindowPos.y;
pDrawList = pWindowDrawList;
pDrawList->AddRectFilled(P1, P2, ImVec4(menu_accent));
