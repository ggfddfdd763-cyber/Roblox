static int hitboxes = 0;
static int fovtypes = 0;
static int PitchMode = 0;
static int AntiAimMode = 0;
static int FovTypeS = 0;

if (Watermark_Bool) {
	MainMenu::Watermark();
}
	
if (nightmode) {
	MainMenu::NightMode();
}

if (hitboxes == 0) {
	silentHead = true;
}
	
if (hitboxes == 1) {
	silentHead = false;
}

bool fdup = true;
bool akkup = true;
bool thhup = true;

if (!fdup) FD();

if (!thhup) TH();

if (akkup) {
    AK();
}

if (FovTypeS == 0) {
	/*fovDefualt = false;
	fovOutline = false;*/
}

if (FovTypeS == 1) {
	/*fovDefualt = true;
	fovOutline = false;*/
}

if (FovTypeS == 2) {
	/*fovDefualt = false;
	fovOutline = true;*/
}

if (PitchMode == 0) {
	AA_SpinDefualt = false;
	AA_SpinUp = false;
}

if (PitchMode == 1) {
	AA_SpinDefualt = true;
	AA_SpinUp = false;
}

if (PitchMode == 2) {
	AA_SpinDefualt = false;
	AA_SpinUp = true;
}

SetNextWindowPos(ImVec2(Screen$$width() * 0.5, Screen$$height() * 0.98), ImGuiCond_Always, ImVec2(0.5, 0.90));
Begin("##BLYAT", NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavInputs | ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoDecoration);
if (Button(u8"                    	", ImVec2(250, 10))) open_menu = !open_menu;
